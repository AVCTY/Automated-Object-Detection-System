from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods
from .models import Product, Inventorycount
from attendance.models import Attendance
from commission.models import Commission
from django.contrib import messages
from django.db.models import Sum
from django.http import JsonResponse
import datetime
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
import csv
import json

# ===================== view inventory code =====================
@login_required
def view_inventory_count(request):
    data = Inventorycount.objects.select_related('productid').all().order_by('-datetoday')

    context = {
        'd':data,
    }
    
    return render(request, 'inventorycount.html', context)


@login_required
@csrf_exempt
def update_inventory(request):
    inventoryid = request.POST.get("id", "")
    type = request.POST.get("type", "")
    value = request.POST.get("value", "")
    response = None
    
    inv = Inventorycount.objects.get(pk=inventoryid)
    
    if type == "number_of_bags":
        inv.noofbags = value
        
    inv.save()

    # Obtains the date which the no of bags are updated
    updatedate = inv.datetoday

    # Checks if there is commission saved on the day and updates the individual commission in the Commission table
    if Commission.objects.filter(currentdate=updatedate).exists():
        # Obtains the number of workers who worked on the day
        att = Attendance.objects.select_related('userid').all()
        noofworkers = att.filter(datetoday=updatedate).count()

        # Obtains the commission row with the date where the number of bags are updated
        com = Commission.objects.get(currentdate=updatedate)

        # Obtains the total number of bags on the day
        totalbags = 0
        invbags = Inventorycount.objects.filter(datetoday=updatedate)

        for bags in invbags:
            totalbags += bags.noofbags

        # Calculates the new individual commission and updates the individual commission
        updatecommission = "{:.2f}".format(totalbags / 5 / noofworkers)
        com.amountpaid = updatecommission
        com.save()

    response = JsonResponse({"message":"Inventory records are updated!"})
    return response

# ===================== Search inventory code =====================
@login_required
def search_inventory(request):
    # Runs when the search button is clicked
    if request.method == "POST":
        # Obtains the data in the drop-down menu
        home_search_inventory = request.POST['search_bag']

        # Obtains the data in the calendar searchbar
        home_search_date = request.POST['search_date']
    else:
        return redirect("view_inventory_count")

    # Checks for non-selected drop-down menu and empty calendar searchbar
    if ((home_search_inventory == "") and (home_search_date == "")):
        return redirect("view_inventory_count")

    # Checks for selected bag in the drop-down menu
    if home_search_inventory != "":
        # Assigns product bag names from the product ID to be shown on webpage
        if home_search_inventory == "1":
            bag_name = "Basedcoat"
        elif home_search_inventory == "2":
            bag_name = "Skim Coat"
        elif home_search_inventory == "4":
            bag_name = "Thin Bed"
        elif home_search_inventory == "5":
            bag_name = "Tile Fix"
        elif home_search_inventory == "6":
            bag_name = "Plastering"
        elif home_search_inventory == "7":
            bag_name = "Screeding"
        elif home_search_inventory == "8":
            bag_name = "Tile Adhesive"
        elif home_search_inventory == "9":
            bag_name = "Brick Joint"

        # Runs if there is no date selected in the calendar searchbar to filter and search by product bag name
        if home_search_date == "":
            # Brings the user to the Inventory Page to show all products
            if home_search_inventory == "0":
                return redirect("view_inventory_count")
            
            # Displays the selected product bag name from the drop-down menu and "All Dates" on the webpage
            bag_view = bag_name
            date_view = "All Dates"

            # Filters for the rows in Inventorycount Table according to product ID(s) searched by product name from the drop-down menu
            data = Inventorycount.objects.select_related('productid').filter(productid__in=home_search_inventory).order_by('-datetoday')

    # Checks for selected date in the calendar searchbar
    if home_search_date != "":
        # Stores the searched dates
        dateToday = []

        # Filters for the rows in Inventorycount Table with the selected date in the calendar searchbar
        home_searched_inventory_date = Inventorycount.objects.filter(datetoday__icontains=home_search_date)

        # Appends the searched inventory dates into an array
        for row in home_searched_inventory_date:
            dateToday.append(row.datetoday)

        # Runs if there is no product bag name selected in the drop-down menu to filter and search by date
        if home_search_inventory == "":
            # Displays "All Bags" and the selected date from the calendar searchbar on the webpage
            bag_view = "All Bags"
            date_view = home_search_date

            # Filters for the rows in Inventorycount Table according to the date in the calendar searchbar
            data = Inventorycount.objects.select_related('productid').filter(datetoday__in=dateToday).order_by('-datetoday')

    # Checks for both the selected bag in the drop-down menu and selected date in the calendar searchbar
    if ((home_search_inventory != "") and (home_search_date != "")):
        # Shows all the bags on the selected date
        if home_search_inventory == "0":
            # Displays "All Bags" and the selected date from the calendar searchbar on the webpage
            bag_view = "All Bags"
            date_view = home_search_date

            # Filters for the rows in Inventorycount Table according to the date in the calendar searchbar
            data = Inventorycount.objects.select_related('productid').filter(datetoday__in=dateToday).order_by('-datetoday')
        else:
            # Displays the selected product bag name from the drop-down menu and the selected date from the calendar searchbar on the webpage
            bag_view = bag_name
            date_view = home_search_date

            # Filters for the rows in Inventorycount Table according to both the product ID(s) searched by product name from the drop-down menu and the date in the calendar searchbar
            data = Inventorycount.objects.select_related('productid').filter(productid__in=home_search_inventory, datetoday__in=dateToday).order_by('-datetoday')

    context = {
        'd':data,
        'title': bag_view,
        'date': date_view
    }

    return render(request, 'inventory_search.html', context)




# ===================== inventory statistics code =====================
@login_required
def view_inventory_stats(request):
    # renders the inventory statistics page
    return render(request, "inventorystats.html")


# ===================== inventory statistics chart code =====================
#@login_required
def product_chart(request):
    if request.method == "POST":
        # checks if monthly or daily input in form exists
        if request.POST.get("monthDate") and request.POST.get("monthDate") != "":
            myStr = request.POST.get("monthDate") # stores the string from request in a temporary variable
            myDate = myStr.split("-") # stores the date in a date variable and split it by '-' in the full string (this will store the split data into a list)
            yyyy = ""
            mm = ""
            dd = ""
            text = ""
            legendText = ""
            labels = []
            data = []
            
            # used to compare the month and get the name of the month for use in the graph title
            monthConvert = {
                "01":"January",
                "02":"February",
                "03":"March",
                "04":"April",
                "05":"May",
                "06":"June",
                "07":"July",
                "08":"August",
                "09":"September",
                "10":"October",
                "11":"November",
                "12":"December",
            }
            
            # checks length of myDate. If 2, its monthly format, if 3, its daily format
            if len(myDate) == 2:
                yyyy = myDate[0] # stores the year
                mm = myDate[1] # stores the month (in number not name format)
                
                # get all records ordered by total bags in descending order
                queryset = Inventorycount.objects.filter(datetoday__year=yyyy, datetoday__month=mm).values("productid__productname").annotate(totalBags=Sum("noofbags")).order_by("-totalBags")
                
                # sets the month for the chart title to name of the month instead of using number
                for key in monthConvert:
                    if key == mm:
                        text = monthConvert[key]
                        legendText = "Product Bar Chart For " + text + " " + yyyy
            elif len(myDate) == 3:
                yyyy = myDate[0] # stores the year
                mm = myDate[1] # stores the month (in number not name format)
                dd = myDate[2] # stores the day/date
                
                # get all records ordered by total bags in descending order
                queryset = Inventorycount.objects.filter(datetoday__year=yyyy, datetoday__month=mm, datetoday__day=dd).values("productid__productname").annotate(totalBags=Sum("noofbags")).order_by("-totalBags")
                
                # sets the month for the chart title to name of the month instead of using number
                for key in monthConvert:
                    if key == mm:
                        text = monthConvert[key]
                        legendText = "Product Bar Chart For " + text + " " + dd + " " + yyyy
            
            # loops through the query and gets the product names and respective total bags produced
            for entry in queryset:
                labels.append(entry["productid__productname"])
                data.append(entry["totalBags"])
                    
            return JsonResponse(data={
                "labels": labels,
                "data": data,
                "text": legendText,
            })
        else:
            # if no date is given, it will generate a chart for all the records
            labels = []
            data = []
            text = ""
            
            # get all records ordered by total bags in descending order
            queryset = Inventorycount.objects.values("productid__productname").annotate(totalBags=Sum("noofbags")).order_by("-totalBags")
            
            # loops through the query and gets the product names and respective total bags produced
            for entry in queryset:
                labels.append(entry["productid__productname"])
                data.append(entry["totalBags"])
                
            text = "Product Bar Chart For All Time"
                    
            return JsonResponse(data={
                "labels": labels,
                "data": data,
                "text": text,
            })


# ===================== inventory report generation code =====================
@login_required
def generate_report(request):
    if request.method == "POST":
        if request.POST.get("monthDate") and request.POST.get("monthDate") != "":
            myStr = request.POST.get("monthDate") # stores the string from request in a temporary variable
            myDate = myStr.split("-") # stores the date in a date variable and split it by '-' in the full string (this will store the split data into a list)
            yyyy = ""
            mm = ""
            dd = ""

            # Create the HttpResponse object with the appropriate CSV header.
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="report.csv"'

            writer = csv.writer(response)
            writer.writerow(['Product_ID', 'Product_Name', 'Bags_Produced', 'DateTime'])
            
            # checks length of myDate. If 2, its monthly format, if 3, its daily format
            if len(myDate) == 2:
                yyyy = myDate[0] # stores the year
                mm = myDate[1] # stores the month (in number not name format)
                invCount = Inventorycount.objects.filter(datetoday__year=yyyy, datetoday__month=mm).values_list('productid', 'productid__productname', 'noofbags', 'datetoday').order_by('-datetoday', 'productid')
            elif len(myDate) == 3:
                yyyy = myDate[0] # stores the year
                mm = myDate[1] # stores the month (in number not name format)
                dd = myDate[2] # stores day/date
                invCount = Inventorycount.objects.filter(datetoday__year=yyyy, datetoday__month=mm, datetoday__day=dd).values_list('productid', 'productid__productname', 'noofbags', 'datetoday').order_by('-datetoday', 'productid')
            
            # loops through the records and writes row into csv
            for icount in invCount:
                writer.writerow(icount)

            return response
        else:
            # Create the HttpResponse object with the appropriate CSV header.
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="report.csv"'

            # code below gets all records and write the rows because no date or month is specified
            writer = csv.writer(response)
            writer.writerow(['Product_ID', 'Product_Name', 'Bags_Produced', 'DateTime'])
            
            invCount = Inventorycount.objects.values_list('productid', 'productid__productname', 'noofbags', 'datetoday').order_by('-datetoday', 'productid')
            for icount in invCount:
                writer.writerow(icount)

            return response
