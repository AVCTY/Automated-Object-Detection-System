from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods
from .models import Product, Inventorycount
from attendance.models import Attendance
from commission.models import Commission
from django.contrib import messages
from django.db.models import Sum
from django.http import JsonResponse
import datetime
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
import csv
import json

# ===================== view inventory code =====================
@login_required
def view_inventory_count(request):
    data = Inventorycount.objects.select_related('productid').all().order_by('-datetoday')

    context = {
        'd':data,
    }

    if request.method == "POST":
        inventoryid = request.POST["inventoryid"]
        noofbags = request.POST["noofbags"]

        if Inventorycount.objects.filter(pk=inventoryid).exists():
            # Obtains the row in the Inventorycount table that matches the Inventory ID
            inv = Inventorycount.objects.get(pk=inventoryid)

            # Obtains the date which the no of bags are updated
            updatedate = inv.datetoday

            # Checks if there is commission saved on the day and updates number of bags in the Inventorycount table and the individual commission in the Commission table
            if Commission.objects.filter(currentdate=updatedate).exists():
                if noofbags == "":
                    inv.save()
                elif noofbags != "":
                    inv.noofbags = noofbags
                    inv.save()

                # Obtains the number of workers who worked on the day
                att = Attendance.objects.select_related('userid').all()
                noofworkers = att.filter(datetoday=updatedate).count()

                # Obtains the commission row with the date where the number of bags are updated
                com = Commission.objects.get(currentdate=updatedate)

                # Obtains the total number of bags on the day
                totalbags = 0
                invbags = Inventorycount.objects.filter(datetoday=updatedate)

                for bags in invbags:
                    totalbags += bags.noofbags

                # Calculates the new individual commission and updates the individual commission
                updatecommission = "{:.2f}".format(totalbags / 5 / noofworkers)
                com.amountpaid = updatecommission
                com.save()

                messages.success(request, "Record Updated!")
            else:
                messages.error(request, "Commission Record is Not Found!")
            return redirect("view_inventory_count")
        else:
            messages.error(request, "Invalid Record!")
            return redirect("view_inventory_count")
    else:
        return render(request, 'inventorycount.html', context)


# ===================== Search inventory code =====================
@login_required
def search_inventory(request):
    # Runs when the search button is clicked
    if request.method == "POST":
        # Obtains the data in the drop-down menu
        home_search_inventory = request.POST['search_bag']

        # Obtains the data in the calendar searchbar
        home_search_date = request.POST['search_date']
    else:
        return redirect("view_inventory_count")

    # Checks for non-selected drop-down menu and empty calendar searchbar
    if ((home_search_inventory == "") and (home_search_date == "")):
        return redirect("view_inventory_count")

    # Checks for selected bag in the drop-down menu
    if home_search_inventory != "":
        # Brings the user to the Inventory Page to show all products
        if home_search_inventory == "0":
            return redirect("view_inventory_count")

        # Assigns product bag names from the product ID to be shown on webpage
        if home_search_inventory == "1":
            bag_name = "Basedcoat"
        elif home_search_inventory == "2":
            bag_name = "Skim Coat"
        elif home_search_inventory == "4":
            bag_name = "Thin Bed"
        elif home_search_inventory == "5":
            bag_name = "Tile Fix"
        elif home_search_inventory == "6":
            bag_name = "Plastering"
        elif home_search_inventory == "7":
            bag_name = "Screeding"
        elif home_search_inventory == "8":
            bag_name = "Tile Adhesive"
        elif home_search_inventory == "9":
            bag_name = "Brick Joint"

        # Runs if there is no date selected in the calendar searchbar to filter and search by product bag name
        if home_search_date == "":
            # Displays the selected product bag name from the drop-down menu and "All Dates" on the webpage
            bag_view = bag_name
            date_view = "All Dates"

            # Filters for the rows in Inventorycount Table according to product ID(s) searched by product name from the drop-down menu
            data = Inventorycount.objects.select_related('productid').filter(productid__in=home_search_inventory).order_by('-datetoday')

    # Checks for selected date in the calendar searchbar
    if home_search_date != "":
        # Stores the searched dates
        dateToday = []

        # Filters for the rows in Inventorycount Table with the selected date in the calendar searchbar
        home_searched_inventory_date = Inventorycount.objects.filter(datetoday__icontains=home_search_date)

        # Appends the searched inventory dates into an array
        for row in home_searched_inventory_date:
            dateToday.append(row.datetoday)

        # Runs if there is no product bag name selected in the drop-down menu to filter and search by date
        if home_search_inventory == "":
            # Displays "All Bags" and the selected date from the calendar searchbar on the webpage
            bag_view = "All Bags"
            date_view = home_search_date

            # Filters for the rows in Inventorycount Table according to the date in the calendar searchbar
            data = Inventorycount.objects.select_related('productid').filter(datetoday__in=dateToday).order_by('-datetoday')

    # Checks for both the selected bag in the drop-down menu and selected date in the calendar searchbar
    if ((home_search_inventory != "") and (home_search_date != "")):
        # Displays the selected product bag name from the drop-down menu and the selected date from the calendar searchbar on the webpage
        bag_view = bag_name
        date_view = home_search_date

        # Filters for the rows in Inventorycount Table according to both the product ID(s) searched by product name from the drop-down menu and the date in the calendar searchbar
        data = Inventorycount.objects.select_related('productid').filter(productid__in=home_search_inventory, datetoday__in=dateToday).order_by('-datetoday')

    context = {
        'd':data,
        'title': bag_view,
        'date': date_view
    }

    return render(request, 'inventory_search.html', context)




# ===================== inventory statistics code =====================
@login_required
def view_inventory_stats(request):
    return render(request, "inventorystats.html")


# ===================== inventory statistics chart code =====================
#@login_required
def product_chart(request):
    if request.method == "POST":
        if request.POST.get("monthDate") and request.POST.get("monthDate") != "":
            myStr = request.POST.get("monthDate")
            myDate = myStr.split("-")
            yyyy = ""
            mm = ""
            dd = ""
            text = ""
            legendText = ""
            labels = []
            data = []
            
            monthConvert = {
                "01":"January",
                "02":"February",
                "03":"March",
                "04":"April",
                "05":"May",
                "06":"June",
                "07":"July",
                "08":"August",
                "09":"September",
                "10":"October",
                "11":"November",
                "12":"December",
            }
            
            if len(myDate) == 2:
                yyyy = myDate[0]
                mm = myDate[1]
                queryset = Inventorycount.objects.filter(datetoday__year=yyyy, datetoday__month=mm).values("productid__productname").annotate(totalBags=Sum("noofbags")).order_by("productid")
                
                for key in monthConvert:
                    if key == mm:
                        text = monthConvert[key]
                        legendText = "Product Bar Chart For " + text + " " + yyyy
            elif len(myDate) == 3:
                yyyy = myDate[0]
                mm = myDate[1]
                dd = myDate[2]
                queryset = Inventorycount.objects.filter(datetoday__year=yyyy, datetoday__month=mm, datetoday__day=dd).values("productid__productname").annotate(totalBags=Sum("noofbags")).order_by("productid")
                
                for key in monthConvert:
                    if key == mm:
                        text = monthConvert[key]
                        legendText = "Product Bar Chart For " + text + " " + dd + " " + yyyy
            
            for entry in queryset:
                labels.append(entry["productid__productname"])
                data.append(entry["totalBags"])
                    
            return JsonResponse(data={
                "labels": labels,
                "data": data,
                "text": legendText,
            })
        else:
            labels = []
            data = []
            text = ""
            
            queryset = Inventorycount.objects.values("productid__productname").annotate(totalBags=Sum("noofbags")).order_by("productid")
            for entry in queryset:
                labels.append(entry["productid__productname"])
                data.append(entry["totalBags"])
                
            text = "Product Bar Chart For All Time"
                    
            return JsonResponse(data={
                "labels": labels,
                "data": data,
                "text": text,
            })


# ===================== inventory report generation code =====================
@login_required
def generate_report(request):
    if request.method == "POST":
        if request.POST.get("monthDate") and request.POST.get("monthDate") != "":
            myStr = request.POST.get("monthDate")
            myDate = myStr.split("-")
            yyyy = ""
            mm = ""
            dd = ""

            # Create the HttpResponse object with the appropriate CSV header.
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="report.csv"'

            writer = csv.writer(response)
            writer.writerow(['Product_ID', 'Product_Name', 'Bags_Produced', 'DateTime'])
            
            if len(myDate) == 2:
                yyyy = myDate[0]
                mm = myDate[1]
                invCount = Inventorycount.objects.filter(datetoday__year=yyyy, datetoday__month=mm).values_list('productid', 'productid__productname', 'noofbags', 'datetoday').order_by('-datetoday', 'productid')
            elif len(myDate) == 3:
                yyyy = myDate[0]
                mm = myDate[1]
                dd = myDate[2]
                invCount = Inventorycount.objects.filter(datetoday__year=yyyy, datetoday__month=mm, datetoday__day=dd).values_list('productid', 'productid__productname', 'noofbags', 'datetoday').order_by('-datetoday', 'productid')
            
            for icount in invCount:
                writer.writerow(icount)

            return response
        else:
            # Create the HttpResponse object with the appropriate CSV header.
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="report.csv"'

            writer = csv.writer(response)
            writer.writerow(['Product_ID', 'Product_Name', 'Bags_Produced', 'DateTime'])
            
            invCount = Inventorycount.objects.values_list('productid', 'productid__productname', 'noofbags', 'datetoday').order_by('-datetoday', 'productid')
            for icount in invCount:
                writer.writerow(icount)

            return response
