from django.shortcuts import render, redirect
from .models import Inventory, Product
from django.contrib import messages
import datetime
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
import csv

# Create your views here.
@login_required
def view_inventory(request):
    current_date = datetime.datetime.now()
    dateonly = datetime.date.today()
    data = Inventory.objects.select_related('productid').all().order_by('-currentdate')

    context = {
        'd':data,
    }

    if request.method == "POST" and "add_record" in request.POST:
        productid = request.POST["productid"]

        if Product.objects.filter(pk=productid).exists() and request.POST["inventoryid"] == "":
            prod = Product.objects.get(pk=productid)
            inv = Inventory()
            inv.productid = prod
            inv.currentdate = current_date
            inv.datetoday = dateonly
            inv.save()
            messages.success(request, "Record Added!")
            return redirect("view_inventory")
        else:
            messages.error(request, "Invalid Action!")
            return redirect("view_inventory")

    elif request.method == "POST" and "remove_record" in request.POST and request.POST["productid"] == "":
        inventoryid = request.POST["inventoryid"]

        if Inventory.objects.filter(pk=inventoryid).exists():
            inv = Inventory.objects.get(pk=inventoryid)
            inv.delete()
            messages.success(request, "Record Deleted!")
            return redirect("view_inventory")
        else:
            messages.error(request, "Invalid Action!")
            return redirect("view_inventory")

    elif request.method == "POST" and "edit_record" in request.POST:
        inventoryid = request.POST["inventoryid"]
        productid = request.POST["productid"]

        if Inventory.objects.filter(pk=inventoryid).exists() and Product.objects.filter(pk=productid).exists():
            inv = Inventory.objects.get(pk=inventoryid)
            prod = Product.objects.get(pk=productid)
            inv.productid = prod
            inv.save()
            messages.success(request, "Record Updated!")
            return redirect("view_inventory")
        else:
            messages.error(request, "Invalid Record or Product ID!")
            return redirect("view_inventory")

    else:
        return render(request, 'inventory.html', context)