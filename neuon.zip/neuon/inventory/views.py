from django.shortcuts import render, redirect
from .models import Product, Inventorycount
from django.contrib import messages
import datetime
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse

# Create your views here.
@login_required
def view_inventory_count(request):
    data = Inventorycount.objects.select_related('productid').all().order_by('-datetoday')

    context = {
        'd':data,
    }

    if request.method == "POST":
        inventoryid = request.POST["inventoryid"]
        noofbags = request.POST["noofbags"]

        if Inventorycount.objects.filter(pk=inventoryid).exists():
            inv = Inventorycount.objects.get(pk=inventoryid)
            if noofbags == "":
                inv.save()
            elif noofbags != "":
                inv.noofbags = noofbags
                inv.save()
            messages.success(request, "Record Updated!")
            return redirect("view_inventory_count")
        else:
            messages.error(request, "Invalid Record!")
            return redirect("view_inventory_count")
    else:
        return render(request, 'inventorycount.html', context)


@login_required
def search_inventory(request):
    # Runs when the search button is clicked
    if request.method == "POST":
        # Obtains the data in the searchbar
        home_search_inventory = request.POST['search_inventory']
    else:
        return redirect("search_inventory")

    # Checks for empty searchbar
    if home_search_inventory == "":
        return redirect("search_inventory")

    # Checks for space in the data in the searchbar (Product Name and Date entry)
    if " " in home_search_inventory:
        inventoryName = home_search_inventory.split(" ")[0]
        inventoryDate = home_search_inventory.split(" ")[1]

        # Stores the searched product IDs
        productID = []

        # Filters for the rows in Product Table with searched names in the searchbar
        home_searched_inventory_name = Product.objects.filter(productname__icontains=inventoryName)

        # Appends the searched product IDs into an array based on the product name
        for row in home_searched_inventory_name:
            productID.append(row.productid)

        # Stores the searched dates
        dateToday = []

        # Filters for the rows in Inventorycount Table with searched dates in the searchbar
        home_searched_inventory_date = Inventorycount.objects.filter(datetoday__icontains=inventoryDate)

        # Appends the searched inventory dates into an array
        for row in home_searched_inventory_date:
            dateToday.append(row.datetoday)

        # Filters for the rows in Inventorycount Table according to product ID(s) searched by product name and according to dates in the searchbar
        data = Inventorycount.objects.select_related('productid').filter(productid__in=productID, datetoday__in=dateToday).order_by('-datetoday')

    else:
        # Checks for '-' in the data in the searchbar (Date entry)
        if "-" in home_search_inventory:
            # Stores the searched dates
            dateToday = []

            # Filters for the rows in Inventorycount Table with searched dates in the searchbar
            home_searched_inventory_date = Inventorycount.objects.filter(datetoday__icontains=home_search_inventory)

            # Appends the searched inventory dates into an array
            for row in home_searched_inventory_date:
                dateToday.append(row.datetoday)

            # Filters for the rows in Inventorycount Table according to dates in the searchbar
            data = Inventorycount.objects.select_related('productid').filter(datetoday__in=dateToday).order_by('-datetoday')
        # Product Name Entry
        else:
            # Stores the searched product IDs
            productID = []

            # Filters for the rows in Product Table with searched names in the searchbar
            home_searched_inventory_name = Product.objects.filter(productname__icontains=home_search_inventory)

            # Appends the searched product IDs into an array based on the product name
            for row in home_searched_inventory_name:
                productID.append(row.productid)

            # Filters for the rows in Inventorycount Table according to product ID(s) searched by product name in the searchbar
            data = Inventorycount.objects.select_related('productid').filter(productid__in=productID).order_by('-datetoday')

    context = {
        'd':data,
        'title': home_search_inventory
    }

    return render(request, 'inventory_search.html', context)