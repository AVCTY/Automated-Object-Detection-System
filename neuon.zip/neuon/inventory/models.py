from django.db import models

# product object model
class Product(models.Model):
    productid = models.AutoField(db_column='productID', primary_key=True)  # Field name made lowercase.
    productname = models.CharField(db_column='productName', max_length=20, blank=True, null=True)  # Field name made lowercase.
    weight = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Product'

# inventory record object model
class Inventorycount(models.Model):
    inventoryid = models.AutoField(db_column='inventoryID', primary_key=True)  # Field name made lowercase.
    productid = models.ForeignKey('Product', models.DO_NOTHING, db_column='productID', blank=True, null=True)  # Field name made lowercase.
    noofbags = models.IntegerField(db_column='noOfBags', blank=True, null=True)  # Field name made lowercase.
    datetoday = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'InventoryCount'