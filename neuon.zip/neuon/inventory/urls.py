from django.urls import path
from . import views

urlpatterns = [
    path("view_inventory", views.view_inventory, name="view_inventory"),
]