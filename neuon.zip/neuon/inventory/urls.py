from django.urls import path
from . import views

urlpatterns = [
    path("view_inventory_count", views.view_inventory_count, name="view_inventory_count"),
    path("update_inventory", views.update_inventory, name="update_inventory"),
    path("search_inventory", views.search_inventory, name="search_inventory"),
    path("view_inventory_stats", views.view_inventory_stats, name="view_inventory_stats"),
    path("product_chart", views.product_chart, name="product_chart"),
    path("generate_report", views.generate_report, name="generate_report"),
]