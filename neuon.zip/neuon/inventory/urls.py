from django.urls import path
from . import views

urlpatterns = [
    path("view_inventory_count", views.view_inventory_count, name="view_inventory_count"),
    path("search_inventory", views.search_inventory, name="search_inventory"),
]