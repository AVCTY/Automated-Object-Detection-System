// Search function to find entry with specific  date
// function Commission_GetDate(){
//     var commission_search_date = document.getElementById("searchTerm_commission").value;
//     document.getElementById("ra").innerHTML = commission_search_date;
// }

// Allows Commission table to expand (Code referenced from https://codepen.io/jopico/pen/kyRprJ)
$(function(){
    $(".table tr.commission_row").on("click", function(){
        $(this).toggleClass("open").next(".commission_hidden").toggleClass("open");
    });
});