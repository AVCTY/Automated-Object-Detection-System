from django.urls import path
from . import views

urlpatterns = [
    path('attendance', views.attendance, name='attendance'),
    path('save_attendance', views.save_attendance, name='save_attendance'),
    path('attendance_employee', views.attendance_employee, name='attendance_employee'),
    path('attendance_employee_save', views.attendance_employee_save, name='attendance_employee_save'),
]