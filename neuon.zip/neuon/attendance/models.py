from django.db import models
from accounts.models import User

# Create your models here.
class Attendance(models.Model):
    attendanceid = models.AutoField(db_column='attendanceID', primary_key=True)  # Field name made lowercase.
    datetoday = models.DateField(blank=True, null=True)
    userid = models.ForeignKey(User, models.DO_NOTHING, db_column='userID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'StaffAttendance'