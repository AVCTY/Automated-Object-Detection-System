from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.decorators import user_passes_test
from .models import Attendance
from django.contrib.auth.decorators import login_required
from datetime import date as d

# Create your views here.

# Attendance Page
@login_required
def attendance(request):
    # Today's date
    dateNow = d.today()

    # Obtains data from Attendance table
    attendanceDisplay = Attendance.objects.select_related('userid').all().order_by("-datetoday")

    return render(request, 'attendance.html', {'DateNow': dateNow,
                                               'AttendanceTable': attendanceDisplay})