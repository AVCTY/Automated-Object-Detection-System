from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.decorators import user_passes_test
from .models import Attendance
from accounts.models import User
from django.contrib.auth.decorators import login_required
from datetime import date as d

# Create your views here.

# Attendance Page
@login_required
def attendance(request):
    # Today's date
    dateNow = d.today()

    # Obtains data from database tables
    employeeDisplay = User.objects.select_related().all().filter(admin=False, manager=False, employee=True).order_by('username')
    attendanceDisplay = Attendance.objects.select_related('userid').all().order_by("-datetoday")[:20]

    # Adds a back button when searching for specific entries
    searchMode = False

    # Changes the '20 entries' message appearance
    attendanceSearch = True

    # Runs when the submit button is clicked
    if request.method == "POST":
        # Obtains the data in the searchbar (Register specific workers' attendance)
        attendanceSearchUsernameId = request.POST.get('attendance_searchUsernameId')

        # Obtains the data in the searchbar (Attendance History)
        attendance_searchHistoryUsernameId = request.POST.get('attendance_searchHistoryUsernameId')

        # Obtains the data in the calendar searchbar (Attendance History)
        attendance_searchHistoryDate = request.POST.get('attendance_searchHistoryDate')

        # Checks if all the searchbars and calendar searchbar in the Attendance webpage are empty (Register attendance and Attendance History)
        if attendanceSearchUsernameId == None and attendance_searchHistoryUsernameId == None and attendance_searchHistoryDate == None:
            return redirect("attendance")

        # Search for specific workers to register attendance
        if attendanceSearchUsernameId != None:
            # Shows the back button
            searchMode = True

            # Checks for ID or username
            if attendanceSearchUsernameId.isdigit():
                # Stores the searched ID
                id_register = []

                # Filters for the rows in Users Table with the searched ID in the searchbar
                users_idRegister = User.objects.filter(id__icontains=attendanceSearchUsernameId)

                # Appends the searched ID into an array based on the ID searched in the searchbar
                for row in users_idRegister:
                    id_register.append(row.id)

                # Filters for the rows in Users Table according to the ID searched in the searchbar
                employeeDisplay = User.objects.filter(id__in=id_register, admin=False, manager=False, employee=True).order_by('username')
            elif attendanceSearchUsernameId.isalpha() or attendanceSearchUsernameId.isalnum():
                # Stores the searched username
                username_register = []

                # Filters for the rows in Users Table with the searched username in the searchbar
                users_usernameRegister = User.objects.filter(username__icontains=attendanceSearchUsernameId)

                # Appends the searched usernames into an array based on the username searched in the searchbar
                for row in users_usernameRegister:
                    username_register.append(row.username)

                # Filters for the rows in Users Table according to the username searched in the searchbar
                employeeDisplay = User.objects.filter(username__in=username_register, admin=False, manager=False, employee=True).order_by('username')
            else:
                return redirect("attendance")

        # Search for specific attendance from the StaffAttendance table (Searchbar and Calendar Searchbar)
        elif attendance_searchHistoryUsernameId != "" and attendance_searchHistoryDate != "":
            # Shows the back button
            searchMode = True

            # Stores the searched username or ID
            usernameid_attendance = []

            # Stores the searched date
            date_attendance = []

            # Checks for ID or username
            if attendance_searchHistoryUsernameId.isdigit():
                # Filters for the rows in Users Table with the searched ID in the searchbar
                users_idRegister = User.objects.filter(id__icontains=attendance_searchHistoryUsernameId)

                # Appends the searched ID into an array based on the ID searched in the searchbar
                for row in users_idRegister:
                    usernameid_attendance.append(row.id)
            elif attendance_searchHistoryUsernameId.isalpha() or attendance_searchHistoryUsernameId.isalnum():
                # Filters for the rows in Users Table with the searched username in the searchbar
                users_usernameAttendance = User.objects.filter(username__icontains=attendance_searchHistoryUsernameId)

                # Appends the searched ID into an array based on the username searched in the searchbar
                for row in users_usernameAttendance:
                    usernameid_attendance.append(row.id)
            else:
                return redirect("attendance")

            # Filters for the rows in StaffAttendance Table with the searched date in the calendar searchbar
            attendance_date = Attendance.objects.filter(datetoday__icontains=attendance_searchHistoryDate)

            # Appends the searched date into an array based on the date searched in the calendar searchbar
            for row in attendance_date:
                date_attendance.append(row.datetoday)

            # Hides the '20 entries' message
            attendanceSearch = False

            # Filters for the rows in StaffAttendance Table according to the username / ID and date searched in the searchbar
            attendanceDisplay = Attendance.objects.select_related('userid').filter(userid__in=usernameid_attendance, datetoday__in=date_attendance).order_by('-datetoday')

        # Search for specific attendance from the StaffAttendance table (Searchbar)
        elif attendance_searchHistoryUsernameId != "":
            # Shows the back button
            searchMode = True

            # Stores the searched username or ID
            usernameid_attendance = []

            # Checks for ID or username
            if attendance_searchHistoryUsernameId.isdigit():
                # Filters for the rows in Users Table with the searched ID in the searchbar
                users_idRegister = User.objects.filter(id__icontains=attendance_searchHistoryUsernameId)

                # Appends the searched ID into an array based on the ID searched in the searchbar
                for row in users_idRegister:
                    usernameid_attendance.append(row.id)
            elif attendance_searchHistoryUsernameId.isalpha() or attendance_searchHistoryUsernameId.isalnum():
                # Filters for the rows in Users Table with the searched username in the searchbar
                users_usernameAttendance = User.objects.filter(username__icontains=attendance_searchHistoryUsernameId)

                # Appends the searched ID into an array based on the username searched in the searchbar
                for row in users_usernameAttendance:
                    usernameid_attendance.append(row.id)
            else:
                return redirect("attendance")

            # Hides the '20 entries' message
            attendanceSearch = False

            # Filters for the rows in StaffAttendance Table according to the username / ID searched in the searchbar
            attendanceDisplay = Attendance.objects.select_related('userid').filter(userid__in=usernameid_attendance).order_by('-datetoday')

        # Search for specific attendance from the StaffAttendance table (Calendar Searchbar)
        elif attendance_searchHistoryDate != "":
            # Shows the back button
            searchMode = True
            
            # Stores the searched date
            date_attendance = []

            # Filters for the rows in StaffAttendance Table with the searched date in the calendar searchbar
            attendance_date = Attendance.objects.filter(datetoday__icontains=attendance_searchHistoryDate)

            # Appends the searched date into an array based on the date searched in the calendar searchbar
            for row in attendance_date:
                date_attendance.append(row.datetoday)

            # Hides the '20 entries' message
            attendanceSearch = False

            # Filters for the rows in StaffAttendance Table according to the date searched in the calendar searchbar
            attendanceDisplay = Attendance.objects.filter(datetoday__in=date_attendance).order_by('-datetoday')
    
    return render(request, 'attendance.html', {'DateNow': dateNow,
                                               'EmployeeTable': employeeDisplay,
                                               'AttendanceTable': attendanceDisplay,
                                               'SearchMode': searchMode,
                                               'AttendanceSearch': attendanceSearch})

# Button to register and save the workers' attendance into the AWS database StaffAttendance table
@login_required
def save_attendance(request):
    # Today's date
    dateNow = d.today()

    if request.method == "POST":
        # Checks if the value of the "value" attribute is "Register"
        if "Register" in request.POST.values():
            # Obtains the user ID from the row where the button is clicked
            register_Id = [key for key in request.POST.keys()][1]

            # Obtains the User instance for user ID
            registerID = User.objects.get(id=register_Id)

            # Checks if the workers have already registered their attendance
            if Attendance.objects.filter(datetoday=dateNow, userid=registerID).exists():
                # Shows an error message
                messages.error(request, "Your attendance was already saved!")
            else:
                # Saves a new attendance entry into the StaffAttendance table
                saveAttendance = Attendance(datetoday=dateNow, userid=registerID)
                saveAttendance.save()
                    
                # Shows a success message
                messages.success(request, "Your attendance is succesfully saved!")

    return redirect("attendance")