from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.decorators import user_passes_test
from .models import Attendance
from accounts.models import User
from inventory.models import Inventorycount
from commission.models import Commission
from django.contrib.auth.decorators import login_required
from datetime import date as d
import calendar

# Attendance Page
@login_required
def attendance(request):
    # Today's date
    dateNow = d.today()

    # Obtains data from database tables
    employeeDisplay = User.objects.select_related().all().filter(admin=False, manager=False, employee=True).order_by('username')
    attendanceDisplay = Attendance.objects.select_related('userid').all().order_by("-datetoday")[:20]

    # Adds a back button when searching for specific entries
    searchMode = False

    # Changes the '20 entries' message appearance
    attendanceSearch = True

    # Runs when the submit button is clicked
    if request.method == "POST":
        # Obtains the data in the searchbar (Register specific workers' attendance)
        attendanceSearchUsernameId = request.POST.get('attendance_searchUsernameId')

        # Obtains the data in the searchbar (Attendance History)
        attendance_searchHistoryUsernameId = request.POST.get('attendance_searchHistoryUsernameId')

        # Obtains the data in the calendar searchbar (Attendance History)
        attendance_searchHistoryDate = request.POST.get('attendance_searchHistoryDate')

        # Checks if all the searchbars and calendar searchbar in the Attendance webpage are empty (Register attendance and Attendance History)
        if attendanceSearchUsernameId == None and attendance_searchHistoryUsernameId == None and attendance_searchHistoryDate == None:
            return redirect("attendance")

        # Search for specific workers to register attendance
        if attendanceSearchUsernameId != None:
            # Shows the back button
            searchMode = True

            # Checks for ID and username
            if attendanceSearchUsernameId.isdigit():
                # Stores the searched ID and username
                id_username_register = []

                # Filters for the rows in Users Table with the searched ID in the searchbar
                users_idRegister = User.objects.filter(id__icontains=attendanceSearchUsernameId)

                # Filters for the rows in Users Table with the searched username in the searchbar
                users_usernameRegisterWId = User.objects.filter(username__icontains=attendanceSearchUsernameId)

                # Appends the searched ID into an array based on the ID searched in the searchbar
                for row in users_idRegister:
                    id_username_register.append(row.id)

                # Appends the searched ID into an array based on the username searched in the searchbar
                for row in users_usernameRegisterWId:
                    id_username_register.append(row.id)

                # Removes duplicates from the array
                id_username_register = list(set(id_username_register))

                # Filters for the rows in Users Table according to the ID searched in the searchbar
                employeeDisplay = User.objects.filter(id__in=id_username_register, admin=False, manager=False, employee=True).order_by('username')
            elif attendanceSearchUsernameId.isalpha() or attendanceSearchUsernameId.isalnum():
                # Stores the searched username
                username_register = []

                # Filters for the rows in Users Table with the searched username in the searchbar
                users_usernameRegister = User.objects.filter(username__icontains=attendanceSearchUsernameId)

                # Appends the searched usernames into an array based on the username searched in the searchbar
                for row in users_usernameRegister:
                    username_register.append(row.username)

                # Filters for the rows in Users Table according to the username searched in the searchbar
                employeeDisplay = User.objects.filter(username__in=username_register, admin=False, manager=False, employee=True).order_by('username')
            else:
                return redirect("attendance")

        # Search for specific attendance from the StaffAttendance table (Searchbar and Calendar Searchbar)
        elif attendance_searchHistoryUsernameId != "" and attendance_searchHistoryDate != "":
            # Shows the back button
            searchMode = True

            # Stores the searched username or ID
            usernameid_attendance = []

            # Stores the searched date
            date_attendance = []

            # Checks for ID and username
            if attendance_searchHistoryUsernameId.isdigit():
                # Filters for the rows in Users Table with the searched ID in the searchbar
                users_idRegister = User.objects.filter(id__icontains=attendance_searchHistoryUsernameId)

                # Filters for the rows in Users Table with the searched username in the searchbar
                users_usernameRegisterWId = User.objects.filter(username__icontains=attendance_searchHistoryUsernameId)

                # Appends the searched ID into an array based on the ID searched in the searchbar
                for row in users_idRegister:
                    usernameid_attendance.append(row.id)

                # Appends the searched ID into an array based on the username searched in the searchbar
                for row in users_usernameRegisterWId:
                    usernameid_attendance.append(row.id)

                # Removes duplicates from the array
                usernameid_attendance = list(set(usernameid_attendance))
            elif attendance_searchHistoryUsernameId.isalpha() or attendance_searchHistoryUsernameId.isalnum():
                # Filters for the rows in Users Table with the searched username in the searchbar
                users_usernameAttendance = User.objects.filter(username__icontains=attendance_searchHistoryUsernameId)

                # Appends the searched ID into an array based on the username searched in the searchbar
                for row in users_usernameAttendance:
                    usernameid_attendance.append(row.id)
            else:
                return redirect("attendance")

            # Filters for the rows in StaffAttendance Table with the searched date in the calendar searchbar
            attendance_date = Attendance.objects.filter(datetoday__icontains=attendance_searchHistoryDate)

            # Appends the searched date into an array based on the date searched in the calendar searchbar
            for row in attendance_date:
                date_attendance.append(row.datetoday)

            # Hides the '20 entries' message
            attendanceSearch = False

            # Filters for the rows in StaffAttendance Table according to the username / ID and date searched in the searchbar
            attendanceDisplay = Attendance.objects.select_related('userid').filter(userid__in=usernameid_attendance, datetoday__in=date_attendance).order_by('-datetoday')

        # Search for specific attendance from the StaffAttendance table (Searchbar)
        elif attendance_searchHistoryUsernameId != "":
            # Shows the back button
            searchMode = True

            # Stores the searched username or ID
            usernameid_attendance = []

            # Checks for ID and username
            if attendance_searchHistoryUsernameId.isdigit():
                # Filters for the rows in Users Table with the searched ID in the searchbar
                users_idRegister = User.objects.filter(id__icontains=attendance_searchHistoryUsernameId)

                # Filters for the rows in Users Table with the searched username in the searchbar
                users_usernameRegisterWId = User.objects.filter(username__icontains=attendance_searchHistoryUsernameId)

                # Appends the searched ID into an array based on the ID searched in the searchbar
                for row in users_idRegister:
                    usernameid_attendance.append(row.id)

                # Appends the searched ID into an array based on the username searched in the searchbar
                for row in users_usernameRegisterWId:
                    usernameid_attendance.append(row.id)

                # Removes duplicates from the array
                usernameid_attendance = list(set(usernameid_attendance))
            elif attendance_searchHistoryUsernameId.isalpha() or attendance_searchHistoryUsernameId.isalnum():
                # Filters for the rows in Users Table with the searched username in the searchbar
                users_usernameAttendance = User.objects.filter(username__icontains=attendance_searchHistoryUsernameId)

                # Appends the searched ID into an array based on the username searched in the searchbar
                for row in users_usernameAttendance:
                    usernameid_attendance.append(row.id)
            else:
                return redirect("attendance")

            # Hides the '20 entries' message
            attendanceSearch = False

            # Filters for the rows in StaffAttendance Table according to the username / ID searched in the searchbar
            attendanceDisplay = Attendance.objects.select_related('userid').filter(userid__in=usernameid_attendance).order_by('-datetoday')

        # Search for specific attendance from the StaffAttendance table (Calendar Searchbar)
        elif attendance_searchHistoryDate != "":
            # Shows the back button
            searchMode = True
            
            # Stores the searched date
            date_attendance = []

            # Filters for the rows in StaffAttendance Table with the searched date in the calendar searchbar
            attendance_date = Attendance.objects.filter(datetoday__icontains=attendance_searchHistoryDate)

            # Appends the searched date into an array based on the date searched in the calendar searchbar
            for row in attendance_date:
                date_attendance.append(row.datetoday)

            # Hides the '20 entries' message
            attendanceSearch = False

            # Filters for the rows in StaffAttendance Table according to the date searched in the calendar searchbar
            attendanceDisplay = Attendance.objects.filter(datetoday__in=date_attendance).order_by('-datetoday')
    
    return render(request, 'attendance.html', {'DateNow': dateNow,
                                               'EmployeeTable': employeeDisplay,
                                               'AttendanceTable': attendanceDisplay,
                                               'SearchMode': searchMode,
                                               'AttendanceSearch': attendanceSearch})

# Button to register and save the workers' attendance into the AWS database StaffAttendance table
@login_required
def save_attendance(request):
    # Today's date
    dateNow = d.today()

    # Obtains data from Attendance table
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Shows the total workers that attended on the day
    totalAttendanceWorker = attendanceDisplay.filter(datetoday=dateNow).count()

    # Checks if the request method is "POST"
    if request.method == "POST":
        # Checks if the value of the "value" attribute is "Check In"
        if "Check In" in request.POST.values():
            # Obtains the user ID from the row where the button is clicked
            register_Id = [key for key in request.POST.keys()][1]

            # Obtains the User instance for user ID
            registerID = User.objects.get(id=register_Id)

            # Checks if the workers have already registered their attendance
            if Attendance.objects.filter(datetoday=dateNow, userid=registerID).exists():
                # Shows an error message
                messages.error(request, "Your attendance was already saved!")
            else:
                # Saves a new attendance entry into the StaffAttendance table
                saveAttendance = Attendance(datetoday=dateNow, userid=registerID)
                saveAttendance.save()

                # Checks if commission is saved today and updates today's commission table row when an attendance is registered
                if Commission.objects.filter(currentdate=dateNow).exists():
                    commissionAttendance = Commission.objects.get(currentdate=dateNow)
                    commissionAttendance.amountpaid = commissionAttendance.amountpaid * totalAttendanceWorker / (totalAttendanceWorker + 1)
                    commissionAttendance.save()
                    
                # Shows a success message
                messages.success(request, "Your attendance is succesfully saved!")
        # Checks if the value of the "value" attribute is "Cancel"
        elif "Cancel" in request.POST.values():
            # Obtains the user ID from the row where the button is clicked
            register_Id = [key for key in request.POST.keys()][1]

            # Obtains the User instance for user ID
            registerID = User.objects.get(id=register_Id)

            # Obtains data from Inventorycount table
            inventoryDisplay = Inventorycount.objects.select_related('productid').all()

            # Shows the daily number of bags produced
            bagsCount = 0
            bagsRow = inventoryDisplay.filter(datetoday=dateNow)

            # Calculates the total number of bags produced on the day
            for bags in bagsRow:
                bagsCount += bags.noofbags

            # Checks if the workers have already registered their attendance
            if Attendance.objects.filter(datetoday=dateNow, userid=registerID).exists():
                if bagsCount > 0 and totalAttendanceWorker == 1:
                    # Shows an error message
                    messages.error(request, "Must have at least one attendance if there are products made!")
                else:
                    # Deletes the workers' attendance entry from the attendance table
                    deleteAttendance = Attendance.objects.get(datetoday=dateNow, userid=registerID)
                    deleteAttendance.delete()

                    # Checks if commission is saved today and updates today's commission table row when an attendance is unregistered
                    if Commission.objects.filter(currentdate=dateNow).exists():
                        commissionAttendance = Commission.objects.get(currentdate=dateNow)
                        commissionAttendance.amountpaid = commissionAttendance.amountpaid * totalAttendanceWorker / (totalAttendanceWorker - 1)
                        commissionAttendance.save()
                    
                    messages.success(request, "Check in entry succesfully deleted!")
            else:
                # Shows an error message
                messages.error(request, "Attendance entry does not exist!")

    return redirect("attendance")

# Employee Attendance Page View
@login_required
def attendance_employee(request):
    # Today's date
    dateNow = d.today()
    monthNow = dateNow.month
    monthNowAlpha = dateNow.strftime("%B")
    yearNow = dateNow.year

    # Obtains data from the Attendance table
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Obtains the ID of the employee logged in
    userCurrent = request.user

    # Runs when the month and year are selected in the calendar searchbar
    if request.method == "POST":
        # Obtains the data in the calendar searchbar
        attendanceSearchMonth = request.POST['attendance_searchMonth']

        # Checks for empty calendar searchbar
        if attendanceSearchMonth == "":
            return redirect("attendance_employee")

        # Splits the data into year and month
        yearSearch = attendanceSearchMonth.split("-")[0]
        monthSearch = attendanceSearchMonth.split("-")[1]

        # Obtains the rows from the Attendance table based on the employee logged in and the attendance made in the searched year and month
        attendanceUser = attendanceDisplay.filter(userid=userCurrent, datetoday__year=yearSearch, datetoday__month=monthSearch).order_by("-datetoday")

        # Shows the searched year and month
        yearNow = yearSearch
        monthNowAlpha = calendar.month_name[int(monthSearch)]
    else:
        # Obtains the rows from the Attendance table based on the employee logged in and the attendance made in the current year and month
        attendanceUser = attendanceDisplay.filter(userid=userCurrent, datetoday__year=yearNow, datetoday__month=monthNow).order_by("-datetoday")

    if Attendance.objects.filter(datetoday=dateNow, userid=userCurrent).exists():
        attendanceStatus = "REGISTERED"
        checkInStatus = "Cancel"
        attendanceButton = "attendanceRegistrationButtonCancel"
    else:
        attendanceStatus = "NOT REGISTERED"
        checkInStatus = "Check In"
        attendanceButton = "attendanceRegistrationButtonSubmit"

    return render(request, 'attendance_employee.html', {'DateNow': dateNow,
                                                        'AttendanceTable': attendanceUser,
                                                        'MonthNowAlpha': monthNowAlpha,
                                                        'YearNow': yearNow,
                                                        'AttendanceStatus': attendanceStatus,
                                                        'CheckInStatus': checkInStatus,
                                                        'AttendanceButton': attendanceButton})

# Button to register and save the individual worker's attendance into the AWS database StaffAttendance table
@login_required
def attendance_employee_save(request):
    # Today's date
    dateNow = d.today()

    # Obtains data from Attendance table
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Shows the total workers that attended on the day
    totalAttendanceWorker = attendanceDisplay.filter(datetoday=dateNow).count()

    # Obtains the ID of the employee logged in
    userCurrent = request.user

    # Checks if the request method is "POST"
    if request.method == "POST":
        # Checks if the value of the "value" attribute is "Check In"
        if "Check In" in request.POST.values():
            # Checks if the workers have already registered their attendance
            if Attendance.objects.filter(datetoday=dateNow, userid=userCurrent).exists():
                # Shows an error message
                messages.error(request, "Your attendance was already saved!")
            else:
                # Saves a new attendance entry into the StaffAttendance table
                saveAttendance = Attendance(datetoday=dateNow, userid=userCurrent)
                saveAttendance.save()

                # Checks if commission is saved today and updates today's commission table row when an attendance is registered
                if Commission.objects.filter(currentdate=dateNow).exists():
                    commissionAttendance = Commission.objects.get(currentdate=dateNow)
                    commissionAttendance.amountpaid = commissionAttendance.amountpaid * totalAttendanceWorker / (totalAttendanceWorker + 1)
                    commissionAttendance.save()
                    
                # Shows a success message
                messages.success(request, "Your attendance is succesfully saved!")
        # Checks if the value of the "value" attribute is "Cancel"
        elif "Cancel" in request.POST.values():
            # Obtains data from Inventorycount table
            inventoryDisplay = Inventorycount.objects.select_related('productid').all()

            # Shows the daily number of bags produced
            bagsCount = 0
            bagsRow = inventoryDisplay.filter(datetoday=dateNow)

            # Calculates the total number of bags produced on the day
            for bags in bagsRow:
                bagsCount += bags.noofbags

            # Checks if the workers have already registered their attendance
            if Attendance.objects.filter(datetoday=dateNow, userid=userCurrent).exists():
                if bagsCount > 0 and totalAttendanceWorker == 1:
                    # Shows an error message
                    messages.error(request, "Must have at least one attendance if there are products made!")
                else:
                    # Deletes the workers' attendance entry from the attendance table
                    deleteAttendance = Attendance.objects.get(datetoday=dateNow, userid=userCurrent)
                    deleteAttendance.delete()

                    # Checks if commission is saved today and updates today's commission table row when an attendance is unregistered
                    if Commission.objects.filter(currentdate=dateNow).exists():
                        commissionAttendance = Commission.objects.get(currentdate=dateNow)
                        commissionAttendance.amountpaid = commissionAttendance.amountpaid * totalAttendanceWorker / (totalAttendanceWorker - 1)
                        commissionAttendance.save()
                    
                    messages.success(request, "Check in entry succesfully deleted!")
            else:
                # Shows an error message
                messages.error(request, "Attendance entry does not exist!")
                
    return redirect("attendance_employee")