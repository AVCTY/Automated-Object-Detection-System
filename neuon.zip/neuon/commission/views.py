from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.decorators import user_passes_test
from inventory.models import Inventorycount
from attendance.models import Attendance
from .models import Commission
from django.contrib.auth.decorators import login_required
from datetime import date as d

# Create your views here.

# Commission Page
@login_required
def commission(request):
    # Today's date
    dateNow = d.today()

    # Obtains data from database tables
    commissionDisplay = Commission.objects.select_related('userid').all().order_by("-currentdate")
    inventoryDisplay = Inventorycount.objects.select_related('productid').all()
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Global attributes
    global bagsCount
    global individualCommission
    global totalAttendanceEmployee

    # Shows the daily number of bags produced
    bagsCount = 0
    bagsRow = inventoryDisplay.filter(datetoday=dateNow)

    # Calculates the total number of bags produced on the day
    for bags in bagsRow:
        bagsCount += bags.noofbags

    # Shows the total commission
    totalCommission = bagsCount/5  # multiply by 0.2 (20 cents per bag)
    totalCommissionFloat = "{:.2f}".format(totalCommission)  # in string

    # Shows the total employees that attended on the day
    totalAttendanceEmployee = attendanceDisplay.filter(datetoday=dateNow).count()

    # Shows the individual commission
    if totalAttendanceEmployee != 0:
        individualCommission = "{:.2f}".format(totalCommission/totalAttendanceEmployee)  # in string
    else:
        individualCommission = "0.00"

    # Shows the different number of each type of product bags on different dates
    totalBasedcoat = []
    totalSkimcoat = []
    totalThinbed = []
    totalTilefix = []
    totalPlastering = []
    totalScreeding = []
    totalTileadhesive = []
    totalBrickjoint = []

    # Stores the number of employees on different dates
    totalEmployeeCount = []

    # Stores the total number of bags on different dates
    totalBagsDate = []

    # Stores the total commission on different dates
    totalAllCommission = []

    # To store all the different dates in the inventorycount table
    inventoryProductDateAfter = []

    # Obtains all the different dates in the datetoday column in the inventorycount table
    inventoryProductDateBefore = Inventorycount.objects.select_related('productid').values_list('datetoday', flat=True).distinct()

    # Puts all the different dates into an array
    for inventoryProductDate in inventoryProductDateBefore:
        inventoryProductDateAfter.append(inventoryProductDate)

    # Removes today's date if date appears in total bags column in inventorycount table but is yet to be saved into the commission table
    if inventoryDisplay.filter(datetoday=dateNow).exists():
        if not Commission.objects.filter(currentdate=dateNow).exists():
            inventoryProductDateAfter.pop()

    # Obtains the number of different product bags and appending the values into arrays designated for each product bag, and calculating the total number of bags for different dates
    for date in inventoryProductDateAfter:
        # Checks whether the date is today
        if date != dateNow:
            # Filters for the number of different product bags on different dates
            basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date)[0].noofbags
            skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date)[0].noofbags
            thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date)[0].noofbags
            tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date)[0].noofbags
            plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date)[0].noofbags
            screedingDate = inventoryDisplay.filter(productid='7', datetoday=date)[0].noofbags
            tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date)[0].noofbags
            brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date)[0].noofbags

            # Counts the total bags produced in the day
            totalBags = basedcoatDate + skimcoatDate + thinbedDate + tilefixDate + plasteringDate + screedingDate + tileadhesiveDate + brickjointDate
        else:
            # Counts the total bags produced in the day
            totalBags = round(Commission.objects.select_related('userid').all().filter(currentdate=dateNow)[0].amountpaid * totalAttendanceEmployee * 5)

            # Checks whether the total bags are the same
            if totalBags != bagsCount:
                # Shows message that the number of different product bags are pending save
                basedcoatDate = skimcoatDate = thinbedDate = tilefixDate = plasteringDate = screedingDate = tileadhesiveDate = brickjointDate = "Pending Save"
            else:
                # Filters for the number of different product bags on today's date
                basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date)[0].noofbags
                skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date)[0].noofbags
                thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date)[0].noofbags
                tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date)[0].noofbags
                plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date)[0].noofbags
                screedingDate = inventoryDisplay.filter(productid='7', datetoday=date)[0].noofbags
                tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date)[0].noofbags
                brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date)[0].noofbags

        # Filters for the number of employees on different dates
        employeeCount = attendanceDisplay.filter(datetoday=date).count()

        # Obtains the individual commission values from the Commission table on different dates
        allDateCommission = Commission.objects.filter(currentdate=date).values('amountpaid')
        
        # Calculates the total commission on different dates
        for commission in allDateCommission:
            allCommission = "{:.2f}".format(commission['amountpaid'] * employeeCount)

        # Rounds off the coins to the first closest decimal before changing back to two decimals if the coins do not end at 0 or 5 cents
        if allCommission[-1] != 5 and allCommission[-1] != 0:
            allCommission = "{:.1f}".format(float(allCommission))
            allCommission = "{:.2f}".format(float(allCommission))

        # Appends into the arrays from the right
        totalBasedcoat.insert(0, basedcoatDate)
        totalSkimcoat.insert(0, skimcoatDate)
        totalThinbed.insert(0, thinbedDate)
        totalTilefix.insert(0, tilefixDate)
        totalPlastering.insert(0, plasteringDate)
        totalScreeding.insert(0, screedingDate)
        totalTileadhesive.insert(0, tileadhesiveDate)
        totalBrickjoint.insert(0, brickjointDate)
        totalEmployeeCount.insert(0, employeeCount)
        totalBagsDate.insert(0, totalBags)
        totalAllCommission.insert(0, allCommission)

    return render(request, 'commission.html', {'DateNow': dateNow,
                                               'CommissionTable': commissionDisplay,
                                               'BagsCount': bagsCount,
                                               'TotalCommission': totalCommissionFloat,
                                               'IndividualCommission': individualCommission,
                                               'TotalBasedcoat': totalBasedcoat,
                                               'TotalSkimcoat': totalSkimcoat,
                                               'TotalThinbed': totalThinbed,
                                               'TotalTilefix': totalTilefix,
                                               'TotalPlastering': totalPlastering,
                                               'TotalScreeding': totalScreeding,
                                               'TotalTileadhesive': totalTileadhesive,
                                               'TotalBrickjoint': totalBrickjoint,
                                               'TotalEmployeeCount': totalEmployeeCount,
                                               'TotalBagsDate': totalBagsDate,
                                               'TotalAllCommission': totalAllCommission})


# Button to save the daily commission into the AWS database Commission table
@login_required
def save_commission(request):
    # Today's date
    dateNow = d.today()

    # Check if the employees have checked in their attendance today
    if totalAttendanceEmployee == 0:
        messages.error(request, "Please check in your attendance!")

        return redirect("commission")
    # Check if product bags are recorded in the inventory today
    elif bagsCount == 0:
        messages.error(request, "No bags produced today!")

        return redirect("commission")
    else:
        # Updates (Does not insert) row when today's row has been generated
        if Commission.objects.filter(currentdate=dateNow).exists():
            commission_today = Commission.objects.get(currentdate=dateNow)
            commission_today.amountpaid = individualCommission
            commission_today.save()
        else:
            saveCommission = Commission(currentdate=dateNow, amountpaid=individualCommission)
            saveCommission.save()
            
        messages.success(request, "Daily commission succesfully saved!")

        return redirect("commission")


# Commission Search Page
@login_required
def search_commission(request):
    # Today's date
    dateNow = d.today()
    
    # Obtains data from database tables
    inventoryDisplay = Inventorycount.objects.select_related('productid').all()
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Shows the daily number of bags produced
    bagsNumber = 0
    bagsRow = inventoryDisplay.filter(datetoday=dateNow)

    # Calculates the total number of bags produced on the day
    for bags in bagsRow:
        bagsNumber += bags.noofbags

    # Obtains the total employees that attended on the day
    totalSearchAttendanceEmployee = attendanceDisplay.filter(datetoday=dateNow).count()

    # Stores the different number of each type of product bags on different dates
    totalBasedcoat = []
    totalSkimcoat = []
    totalThinbed = []
    totalTilefix = []
    totalPlastering = []
    totalScreeding = []
    totalTileadhesive = []
    totalBrickjoint = []

    # Stores the number of employees on different dates
    totalEmployeeCount = []

    # Stores the total number of bags on different dates
    totalBagsDate = []

    # Stores the total commission on different dates
    totalAllCommission = []

    # Runs when a date is selected in the calendar searchbar
    if request.method == "POST":
        # Stores the dates in the commission table
        searchCommissionDate= []

        # Stores the dates in the inventorycount table
        searchInventoryDate = []

        # Stores the common dates in the two arrays
        searchDate = []

        # Obtains the data in the calendar searchbar
        commissionSearchDate = request.POST['commission_searchDate']

        # Checks for empty calendar searchbar
        if commissionSearchDate == "":
            return redirect("commission")

        # Filters for the rows in commission table with searched dates in the calendar searchbar
        commissionSearchedDate = Commission.objects.filter(currentdate__icontains=commissionSearchDate).order_by("-currentdate")

        # Obtains all the different dates in the datetoday column in the inventorycount table
        inventorySearchedDate = Inventorycount.objects.select_related('productid').values_list('datetoday', flat=True).distinct()

        # Obtains the dates from the searched rows and appends them into an array
        for row in commissionSearchedDate:
            searchCommissionDate.append(row.currentdate)

        # Obtains the dates from the commission table in the database
        for date in inventorySearchedDate:
            searchInventoryDate.append(date)

        # Compares the two arrays above and obtains an array with the same dates
        searchDate = list(set(searchCommissionDate).intersection(searchInventoryDate))

        # Arranges the dates in the array
        searchDate.sort()

        # Obtains the number of different product bags and appending the values into arrays designated for each product bag
        for inventoryProductDate in searchDate:
            # Checks whether the date is today
            if inventoryProductDate != dateNow:
                # Filters for the number of different product bags on different dates
                basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=inventoryProductDate)[0].noofbags
                skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=inventoryProductDate)[0].noofbags
                thinbedDate = inventoryDisplay.filter(productid='4', datetoday=inventoryProductDate)[0].noofbags
                tilefixDate = inventoryDisplay.filter(productid='5', datetoday=inventoryProductDate)[0].noofbags
                plasteringDate = inventoryDisplay.filter(productid='6', datetoday=inventoryProductDate)[0].noofbags
                screedingDate = inventoryDisplay.filter(productid='7', datetoday=inventoryProductDate)[0].noofbags
                tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=inventoryProductDate)[0].noofbags
                brickjointDate = inventoryDisplay.filter(productid='9', datetoday=inventoryProductDate)[0].noofbags

                # Counts the total bags produced in the day
                totalBags = basedcoatDate + skimcoatDate + thinbedDate + tilefixDate + plasteringDate + screedingDate + tileadhesiveDate + brickjointDate
            else:
                # Counts the total bags produced in the day
                totalBags = round(Commission.objects.select_related('userid').all().filter(currentdate=dateNow)[0].amountpaid * totalSearchAttendanceEmployee * 5)

                # Checks whether the total bags are the same
                if totalBags != bagsNumber:
                    # Shows message that the number of different product bags are pending save
                    basedcoatDate = skimcoatDate = thinbedDate = tilefixDate = plasteringDate = screedingDate = tileadhesiveDate = brickjointDate = "Pending Save"
                else:
                    # Filters for the number of different product bags on today's date
                    basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=inventoryProductDate)[0].noofbags
                    skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=inventoryProductDate)[0].noofbags
                    thinbedDate = inventoryDisplay.filter(productid='4', datetoday=inventoryProductDate)[0].noofbags
                    tilefixDate = inventoryDisplay.filter(productid='5', datetoday=inventoryProductDate)[0].noofbags
                    plasteringDate = inventoryDisplay.filter(productid='6', datetoday=inventoryProductDate)[0].noofbags
                    screedingDate = inventoryDisplay.filter(productid='7', datetoday=inventoryProductDate)[0].noofbags
                    tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=inventoryProductDate)[0].noofbags
                    brickjointDate = inventoryDisplay.filter(productid='9', datetoday=inventoryProductDate)[0].noofbags
            
            # Filters for the number of employees on different dates
            employeeCount = attendanceDisplay.filter(datetoday=inventoryProductDate).count()

            # Obtains the individual commission values from the Commission table on different dates
            allDateCommission = Commission.objects.filter(currentdate=inventoryProductDate).values('amountpaid')
            
            # Calculates the total commission on different dates
            for commission in allDateCommission:
                allCommission = "{:.2f}".format(commission['amountpaid'] * employeeCount)

            # Rounds off the coins to the first closest decimal before changing back to two decimals if the coins do not end at 0 or 5 cents
            if allCommission[-1] != 5 and allCommission[-1] != 0:
                allCommission = "{:.1f}".format(float(allCommission))
                allCommission = "{:.2f}".format(float(allCommission))

            # Appends into the arrays from the right
            totalBasedcoat.insert(0, basedcoatDate)
            totalSkimcoat.insert(0, skimcoatDate)
            totalThinbed.insert(0, thinbedDate)
            totalTilefix.insert(0, tilefixDate)
            totalPlastering.insert(0, plasteringDate)
            totalScreeding.insert(0, screedingDate)
            totalTileadhesive.insert(0, tileadhesiveDate)
            totalBrickjoint.insert(0, brickjointDate)
            totalEmployeeCount.insert(0, employeeCount)
            totalBagsDate.insert(0, totalBags)
            totalAllCommission.insert(0, allCommission)

        return render(request, 'commission_search.html', {'CommissionTable': commissionSearchedDate,
                                                          'TotalSearchAttendanceEmployee': totalSearchAttendanceEmployee,
                                                          'TotalBasedcoat': totalBasedcoat,
                                                          'TotalSkimcoat': totalSkimcoat,
                                                          'TotalThinbed': totalThinbed,
                                                          'TotalTilefix': totalTilefix,
                                                          'TotalPlastering': totalPlastering,
                                                          'TotalScreeding': totalScreeding,
                                                          'TotalTileadhesive': totalTileadhesive,
                                                          'TotalBrickjoint': totalBrickjoint,
                                                          'TotalEmployeeCount': totalEmployeeCount,
                                                          'TotalBagsDate': totalBagsDate,
                                                          'TotalAllCommission': totalAllCommission,
                                                          'CommissionTitle': commissionSearchDate})