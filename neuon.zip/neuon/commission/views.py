from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.decorators import user_passes_test
from inventory.models import Inventory
from accounts.models import User
from .models import Commission
from django.contrib.auth.decorators import login_required
from datetime import date

# Today's date
dateNow = date.today()

# Create your views here.
@login_required
@user_passes_test(lambda u: u.is_admin or u.is_manager)
def commission(request):
    commissionDisplay = Commission.objects.select_related('userid').all().order_by("-currentdate")
    inventoryDisplay = Inventory.objects.select_related('productid').all()
    employeeDisplay = User.objects.select_related().all().filter(admin=False, manager=False, employee=True)

    # Shows the daily number of bags produced, total commission, total employees and individual commission
    global bagsCount
    global individualCommission

    bagsCount = inventoryDisplay.filter(datetoday=dateNow).count()
    totalCommission = bagsCount/5
    totalCommissionFloat = "{:.2f}".format(totalCommission)  # in string

    totalEmployee = employeeDisplay.count()
    individualCommission = "{:.2f}".format(totalCommission/totalEmployee)  # in string

    # To show the different number of each type of product bags on different dates
    totalBasedcoat = []
    totalBrickjoint = []
    totalPlastering = []
    totalScreeding = []
    totalSkimcoat = []
    totalThinbed = []
    totalTileadhesive = []
    totalTilefix = []

    # Stores the total number of bags on different dates
    totalBagsDate = []

    # To store all the different dates in the inventory table
    inventoryProductDateAfter = []

    # Obtains all the different dates in the datetoday column in the inventory table
    inventoryProductDateBefore = Inventory.objects.select_related('productid').values_list('datetoday', flat=True).distinct()

    # Puts all the different dates into an array
    for inventoryProductDate in inventoryProductDateBefore:
        inventoryProductDateAfter.append(inventoryProductDate)

    # Removes today's date if date appears in inventory table but is yet to be saved into the commission table
    if inventoryDisplay.filter(datetoday=dateNow).exists():
        if not Commission.objects.filter(currentdate=dateNow).exists():
            inventoryProductDateAfter.pop()

    # Obtains the number of different product bags and appending the values into arrays designated for each product bag
    for date in inventoryProductDateAfter:
        # Filters for the number of different product bags on different dates
        basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date).count()
        brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date).count()
        plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date).count()
        screedingDate = inventoryDisplay.filter(productid='7', datetoday=date).count()
        skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date).count()
        thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date).count()
        tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date).count()
        tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date).count()

        # Counts the total bags produced in the day
        totalBags = basedcoatDate + brickjointDate + plasteringDate + screedingDate + skimcoatDate + thinbedDate + tileadhesiveDate + tilefixDate

        # Appends into the arrays from the right
        totalBasedcoat.insert(0, basedcoatDate)
        totalBrickjoint.insert(0, brickjointDate)
        totalPlastering.insert(0, plasteringDate)
        totalScreeding.insert(0, screedingDate)
        totalSkimcoat.insert(0, skimcoatDate)
        totalThinbed.insert(0, thinbedDate)
        totalTileadhesive.insert(0, tileadhesiveDate)
        totalTilefix.insert(0, tilefixDate)

        totalBagsDate.insert(0, totalBags)

    return render(request, 'commission.html', {'DateNow': dateNow,
                                               'CommissionTable': commissionDisplay,
                                               'EmployeeTable': employeeDisplay,
                                               'BagsCount': bagsCount,
                                               'TotalCommission': totalCommissionFloat,
                                               'TotalEmployee': totalEmployee,
                                               'IndividualCommission': individualCommission,
                                               'TotalBasedcoat': totalBasedcoat,
                                               'TotalBrickjoint': totalBrickjoint,
                                               'TotalPlastering': totalPlastering,
                                               'TotalScreeding': totalScreeding,
                                               'TotalSkimcoat': totalSkimcoat,
                                               'TotalThinbed': totalThinbed,
                                               'TotalTileadhesive': totalTileadhesive,
                                               'TotalTilefix': totalTilefix,
                                               'TotalBagsDate': totalBagsDate})


# Button to save the daily commission into the AWS database Commission table
@login_required
@user_passes_test(lambda u: u.is_admin or u.is_manager)
def save_commission(request):
    # Check if product bags are recorded in the inventory today
    if bagsCount == 0:
        messages.error(request, "No bags produced today!")

        return redirect("commission")
    else:
        # Updates (Does not insert) row when today's row has been generated
        if Commission.objects.filter(currentdate=dateNow).exists():
            commission_today = Commission.objects.get(currentdate=dateNow)
            commission_today.amountpaid = individualCommission
            commission_today.save()
        else:
            saveCommission = Commission(currentdate=dateNow, amountpaid=individualCommission)
            saveCommission.save()
            
        messages.success(request, "Daily commission succesfully saved!")

        return redirect("commission")


# Commission Search Page
@login_required
@user_passes_test(lambda u: u.is_admin or u.is_manager)
def search_commission(request):
    # Obtains data from database tables
    inventoryDisplay = Inventory.objects.select_related('productid').all()
    employeeDisplay = User.objects.select_related().all().filter(admin=False, manager=False, employee=True)

    # Obtains the total employees
    totalEmployee = employeeDisplay.count()

    # Stores the different number of each type of product bags on different dates
    totalBasedcoat = []
    totalBrickjoint = []
    totalPlastering = []
    totalScreeding = []
    totalSkimcoat = []
    totalThinbed = []
    totalTileadhesive = []
    totalTilefix = []

    # Stores the total number of bags on different dates
    totalBagsDate = []

    # Runs when the search button is clicked
    if request.method == "POST":
        searchCommissionDate= []
        searchInventoryDate = []
        searchDate = []

        # Obtains the data in the searchbar
        commissionSearchDate = request.POST['commission_searchDate']

        # Checks for empty searchbar
        if commissionSearchDate == "":
            return redirect("commission")

        # Filters for the rows in commission table with searched dates in the searchbar
        commissionSearchedDate = Commission.objects.filter(currentdate__icontains=commissionSearchDate).order_by("-currentdate")

        # Obtains all the different dates in the datetoday column in the inventory table
        inventorySearchedDate = Inventory.objects.select_related('productid').values_list('datetoday', flat=True).distinct()

        # Obtains the dates from the searched rows and appends them into an array
        for row in commissionSearchedDate:
            searchCommissionDate.append(row.currentdate)

        # Obtains the dates from the commission table in the database
        for date in inventorySearchedDate:
            searchInventoryDate.append(date)

        # Compares the two arrays above and obtains an array with the same dates
        searchDate = list(set(searchCommissionDate).intersection(searchInventoryDate))

        # Arranges the dates in the array
        searchDate.sort()

        # Obtains the number of different product bags and appending the values into arrays designated for each product bag
        for inventoryProductDate in searchDate:
            # Filters for the number of different product bags on different dates
            basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=inventoryProductDate).count()
            brickjointDate = inventoryDisplay.filter(productid='9', datetoday=inventoryProductDate).count()
            plasteringDate = inventoryDisplay.filter(productid='6', datetoday=inventoryProductDate).count()
            screedingDate = inventoryDisplay.filter(productid='7', datetoday=inventoryProductDate).count()
            skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=inventoryProductDate).count()
            thinbedDate = inventoryDisplay.filter(productid='4', datetoday=inventoryProductDate).count()
            tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=inventoryProductDate).count()
            tilefixDate = inventoryDisplay.filter(productid='5', datetoday=inventoryProductDate).count()

            # Counts the total bags produced in the day
            totalBags = basedcoatDate + brickjointDate + plasteringDate + screedingDate + skimcoatDate + thinbedDate + tileadhesiveDate + tilefixDate

            # Appends into the arrays from the right
            totalBasedcoat.insert(0, basedcoatDate)
            totalBrickjoint.insert(0, brickjointDate)
            totalPlastering.insert(0, plasteringDate)
            totalScreeding.insert(0, screedingDate)
            totalSkimcoat.insert(0, skimcoatDate)
            totalThinbed.insert(0, thinbedDate)
            totalTileadhesive.insert(0, tileadhesiveDate)
            totalTilefix.insert(0, tilefixDate)

            totalBagsDate.insert(0, totalBags)

        return render(request, 'commission_search.html', {'CommissionTable': commissionSearchedDate,
                                                          'TotalEmployee': totalEmployee,
                                                          'TotalBasedcoat': totalBasedcoat,
                                                          'TotalBrickjoint': totalBrickjoint,
                                                          'TotalPlastering': totalPlastering,
                                                          'TotalScreeding': totalScreeding,
                                                          'TotalSkimcoat': totalSkimcoat,
                                                          'TotalThinbed': totalThinbed,
                                                          'TotalTileadhesive': totalTileadhesive,
                                                          'TotalTilefix': totalTilefix,
                                                          'TotalBagsDate': totalBagsDate,
                                                          'CommissionTitle': commissionSearchDate})