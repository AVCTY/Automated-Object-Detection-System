from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.decorators import user_passes_test
from inventory.models import Inventorycount
from accounts.models import User
from .models import Commission
from django.contrib.auth.decorators import login_required
from datetime import date

# Create your views here.

# Commission Page
@login_required
@user_passes_test(lambda u: u.is_admin or u.is_manager)
def commission(request):
    # Today's date
    dateNow = date.today()

    commissionDisplay = Commission.objects.select_related('userid').all().order_by("-currentdate")
    inventoryDisplay = Inventorycount.objects.select_related('productid').all()
    employeeAttendanceDisplay = User.objects.select_related().all().filter(admin=False, manager=False, employee=True)

    global bagsCount
    global individualCommission

    # Shows the daily number of bags produced
    bagsCount = 0
    bagsRow = inventoryDisplay.filter(datetoday=dateNow)

    for bags in bagsRow:
        bagsCount += bags.noofbags

    # Shows the total commission
    totalCommission = bagsCount/5  # multiply by 0.2 (20 cents per bag)
    totalCommissionFloat = "{:.2f}".format(totalCommission)  # in string

    # Shows the total employees that attended on the day
    totalAttendanceEmployee = employeeAttendanceDisplay.count()

    # Shows the individual commission
    individualCommission = "{:.2f}".format(totalCommission/totalAttendanceEmployee)  # in string

    # Shows the different number of each type of product bags on different dates
    totalBasedcoat = []
    totalBrickjoint = []
    totalPlastering = []
    totalScreeding = []
    totalSkimcoat = []
    totalThinbed = []
    totalTileadhesive = []
    totalTilefix = []

    # Stores the total number of bags on different dates
    totalBagsDate = []

    # To store all the different dates in the inventorycount table
    inventoryProductDateAfter = []

    # Obtains all the different dates in the datetoday column in the inventorycount table
    inventoryProductDateBefore = Inventorycount.objects.select_related('productid').values_list('datetoday', flat=True).distinct()

    # Puts all the different dates into an array
    for inventoryProductDate in inventoryProductDateBefore:
        inventoryProductDateAfter.append(inventoryProductDate)

    # Removes today's date if date appears in total bags column in inventorycount table but is yet to be saved into the commission table
    if inventoryDisplay.filter(datetoday=dateNow).exists():
        if not Commission.objects.filter(currentdate=dateNow).exists():
            inventoryProductDateAfter.pop()

    # Obtains the number of different product bags and appending the values into arrays designated for each product bag, and calculating the total number of bags for different dates
    for date in inventoryProductDateAfter:
        # Checks whether the date is today
        if date != dateNow:
            # Filters for the number of different product bags on different dates
            basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date)[0].noofbags
            brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date)[0].noofbags
            plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date)[0].noofbags
            screedingDate = inventoryDisplay.filter(productid='7', datetoday=date)[0].noofbags
            skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date)[0].noofbags
            thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date)[0].noofbags
            tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date)[0].noofbags
            tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date)[0].noofbags

            # Counts the total bags produced in the day
            totalBags = basedcoatDate + brickjointDate + plasteringDate + screedingDate + skimcoatDate + thinbedDate + tileadhesiveDate + tilefixDate
        else:
            # Counts the total bags produced in the day
            totalBags = int(Commission.objects.select_related('userid').all().filter(currentdate=dateNow)[0].amountpaid * totalAttendanceEmployee * 5)

            # Checks whether the total bags are the same
            if totalBags != bagsCount:
                # Shows message that the number of different product bags are pending save
                basedcoatDate = brickjointDate = plasteringDate = screedingDate = skimcoatDate = thinbedDate = tileadhesiveDate = tilefixDate = "Pending Save"
            else:
                # Filters for the number of different product bags on today's date
                basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date)[0].noofbags
                brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date)[0].noofbags
                plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date)[0].noofbags
                screedingDate = inventoryDisplay.filter(productid='7', datetoday=date)[0].noofbags
                skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date)[0].noofbags
                thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date)[0].noofbags
                tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date)[0].noofbags
                tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date)[0].noofbags

        # Appends into the arrays from the right
        totalBasedcoat.insert(0, basedcoatDate)
        totalBrickjoint.insert(0, brickjointDate)
        totalPlastering.insert(0, plasteringDate)
        totalScreeding.insert(0, screedingDate)
        totalSkimcoat.insert(0, skimcoatDate)
        totalThinbed.insert(0, thinbedDate)
        totalTileadhesive.insert(0, tileadhesiveDate)
        totalTilefix.insert(0, tilefixDate)

        totalBagsDate.insert(0, totalBags)

    return render(request, 'commission.html', {'DateNow': dateNow,
                                               'CommissionTable': commissionDisplay,
                                               'AttendanceTable': employeeAttendanceDisplay,
                                               'BagsCount': bagsCount,
                                               'TotalCommission': totalCommissionFloat,
                                               'TotalAttendanceEmployee': totalAttendanceEmployee,
                                               'IndividualCommission': individualCommission,
                                               'TotalBasedcoat': totalBasedcoat,
                                               'TotalBrickjoint': totalBrickjoint,
                                               'TotalPlastering': totalPlastering,
                                               'TotalScreeding': totalScreeding,
                                               'TotalSkimcoat': totalSkimcoat,
                                               'TotalThinbed': totalThinbed,
                                               'TotalTileadhesive': totalTileadhesive,
                                               'TotalTilefix': totalTilefix,
                                               'TotalBagsDate': totalBagsDate})


# Button to save the daily commission into the AWS database Commission table
@login_required
@user_passes_test(lambda u: u.is_admin or u.is_manager)
def save_commission(request):
    # Today's date
    dateNow = date.today()

    # Check if product bags are recorded in the inventory today
    if bagsCount == 0:
        messages.error(request, "No bags produced today!")

        return redirect("commission")
    else:
        # Updates (Does not insert) row when today's row has been generated
        if Commission.objects.filter(currentdate=dateNow).exists():
            commission_today = Commission.objects.get(currentdate=dateNow)
            commission_today.amountpaid = individualCommission
            commission_today.save()
        else:
            saveCommission = Commission(currentdate=dateNow, amountpaid=individualCommission)
            saveCommission.save()
            
        messages.success(request, "Daily commission succesfully saved!")

        return redirect("commission")


# Commission Search Page
@login_required
@user_passes_test(lambda u: u.is_admin or u.is_manager)
def search_commission(request):
    # Today's date
    dateNow = date.today()

    # Obtains data from database tables
    inventoryDisplay = Inventorycount.objects.select_related('productid').all()
    employeeAttendanceDisplay = User.objects.select_related().all().filter(admin=False, manager=False, employee=True)

    # Shows the daily number of bags produced
    bagsNumber = 0
    bagsRow = inventoryDisplay.filter(datetoday=dateNow)

    for bags in bagsRow:
        bagsNumber += bags.noofbags

    # Obtains the total employees that attended on the day
    totalAttendanceEmployee = employeeAttendanceDisplay.count()

    # Stores the different number of each type of product bags on different dates
    totalBasedcoat = []
    totalBrickjoint = []
    totalPlastering = []
    totalScreeding = []
    totalSkimcoat = []
    totalThinbed = []
    totalTileadhesive = []
    totalTilefix = []

    # Stores the total number of bags on different dates
    totalBagsDate = []

    # Runs when the search button is clicked
    if request.method == "POST":
        # Stores the dates in the commission table
        searchCommissionDate= []

        # Stores the dates in the inventorycount table
        searchInventoryDate = []

        # Stores the common dates in the two arrays
        searchDate = []

        # Obtains the data in the searchbar
        commissionSearchDate = request.POST['commission_searchDate']

        # Checks for empty searchbar
        if commissionSearchDate == "":
            return redirect("commission")

        # Filters for the rows in commission table with searched dates in the searchbar
        commissionSearchedDate = Commission.objects.filter(currentdate__icontains=commissionSearchDate).order_by("-currentdate")

        # Obtains all the different dates in the datetoday column in the inventorycount table
        inventorySearchedDate = Inventorycount.objects.select_related('productid').values_list('datetoday', flat=True).distinct()

        # Obtains the dates from the searched rows and appends them into an array
        for row in commissionSearchedDate:
            searchCommissionDate.append(row.currentdate)

        # Obtains the dates from the commission table in the database
        for date in inventorySearchedDate:
            searchInventoryDate.append(date)

        # Compares the two arrays above and obtains an array with the same dates
        searchDate = list(set(searchCommissionDate).intersection(searchInventoryDate))

        # Arranges the dates in the array
        searchDate.sort()

        # Obtains the number of different product bags and appending the values into arrays designated for each product bag
        for inventoryProductDate in searchDate:
            # Checks whether the date is today
            if inventoryProductDate != dateNow:
                # Filters for the number of different product bags on different dates
                basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=inventoryProductDate)[0].noofbags
                brickjointDate = inventoryDisplay.filter(productid='9', datetoday=inventoryProductDate)[0].noofbags
                plasteringDate = inventoryDisplay.filter(productid='6', datetoday=inventoryProductDate)[0].noofbags
                screedingDate = inventoryDisplay.filter(productid='7', datetoday=inventoryProductDate)[0].noofbags
                skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=inventoryProductDate)[0].noofbags
                thinbedDate = inventoryDisplay.filter(productid='4', datetoday=inventoryProductDate)[0].noofbags
                tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=inventoryProductDate)[0].noofbags
                tilefixDate = inventoryDisplay.filter(productid='5', datetoday=inventoryProductDate)[0].noofbags

                # Counts the total bags produced in the day
                totalBags = basedcoatDate + brickjointDate + plasteringDate + screedingDate + skimcoatDate + thinbedDate + tileadhesiveDate + tilefixDate
            else:
                # Counts the total bags produced in the day
                totalBags = int(Commission.objects.select_related('userid').all().filter(currentdate=dateNow)[0].amountpaid * totalAttendanceEmployee * 5)

                # Checks whether the total bags are the same
                if totalBags != bagsNumber:
                    # Shows message that the number of different product bags are pending save
                    basedcoatDate = brickjointDate = plasteringDate = screedingDate = skimcoatDate = thinbedDate = tileadhesiveDate = tilefixDate = "Pending Save"
                else:
                    # Filters for the number of different product bags on today's date
                    basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date)[0].noofbags
                    brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date)[0].noofbags
                    plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date)[0].noofbags
                    screedingDate = inventoryDisplay.filter(productid='7', datetoday=date)[0].noofbags
                    skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date)[0].noofbags
                    thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date)[0].noofbags
                    tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date)[0].noofbags
                    tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date)[0].noofbags

            # Appends into the arrays from the right
            totalBasedcoat.insert(0, basedcoatDate)
            totalBrickjoint.insert(0, brickjointDate)
            totalPlastering.insert(0, plasteringDate)
            totalScreeding.insert(0, screedingDate)
            totalSkimcoat.insert(0, skimcoatDate)
            totalThinbed.insert(0, thinbedDate)
            totalTileadhesive.insert(0, tileadhesiveDate)
            totalTilefix.insert(0, tilefixDate)

            totalBagsDate.insert(0, totalBags)

        return render(request, 'commission_search.html', {'CommissionTable': commissionSearchedDate,
                                                          'TotalAttendanceEmployee': totalAttendanceEmployee,
                                                          'TotalBasedcoat': totalBasedcoat,
                                                          'TotalBrickjoint': totalBrickjoint,
                                                          'TotalPlastering': totalPlastering,
                                                          'TotalScreeding': totalScreeding,
                                                          'TotalSkimcoat': totalSkimcoat,
                                                          'TotalThinbed': totalThinbed,
                                                          'TotalTileadhesive': totalTileadhesive,
                                                          'TotalTilefix': totalTilefix,
                                                          'TotalBagsDate': totalBagsDate,
                                                          'CommissionTitle': commissionSearchDate})