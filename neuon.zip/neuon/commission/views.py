from ast import Delete
from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.decorators import user_passes_test
from inventory.models import Inventorycount
from attendance.models import Attendance
from .models import Commission
from django.contrib.auth.decorators import login_required
from datetime import date as d
import calendar

# Commission Page
@login_required
def commission(request):
    # Today's date
    dateNow = d.today()

    # Obtains data from database tables
    commissionDisplay = Commission.objects.select_related('userid').all()
    inventoryDisplay = Inventorycount.objects.select_related('productid').all()
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Updates the previous Commission table entry if it is not updated (Button not saved)
    # Checks whether there is an entry in the Commission table
    if commissionDisplay.last() != "":
        # Obtains the date of the last entry in the Commission table
        commissionDateUpdateCheck = commissionDisplay.values_list('currentdate', flat=True).last()

        # Checks if the date of the last entry in the Commission table is the current date
        if commissionDateUpdateCheck != dateNow:
            # Contains the total bags made on the previous day
            bagsPrevious = 0

            # Obtains the rows of different product bags made on the previous day
            inventoryTotalPrevious = inventoryDisplay.filter(datetoday=commissionDateUpdateCheck)

            # Calculates the total bags made on the previous day
            for bags in inventoryTotalPrevious:
                bagsPrevious += bags.noofbags

            # Obtains the total attendance on the previous day
            attendancePrevious = attendanceDisplay.filter(datetoday=commissionDateUpdateCheck).count()

            # Calculates the actual updated individual commission amount
            commissionSelfUpdate = "{:.2f}".format(bagsPrevious / 5 / attendancePrevious)

            # Obtains the previous individual commission saved in the Commission table
            commissionUpdateCheck = commissionDisplay.values_list('amountpaid', flat=True).last()
            commissionUpdateCheck = str(commissionUpdateCheck)

            # Checks if the individual commission of the previous entry is correct
            if commissionSelfUpdate != commissionUpdateCheck:
                # Saves the updated commission to the previous date
                if Commission.objects.filter(currentdate=commissionDateUpdateCheck).exists():
                    commissionUpdate = Commission.objects.get(currentdate=commissionDateUpdateCheck)
                    commissionUpdate.amountpaid = commissionSelfUpdate
                    commissionUpdate.save()

    # Obtains data from the updated database tables
    commissionDisplay = Commission.objects.select_related('userid').all().order_by("-currentdate")[:20]
    inventoryDisplay = Inventorycount.objects.select_related('productid').all()
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Global attributes
    global bagsCount
    global individualCommission
    global totalAttendanceEmployee

    # Shows the daily number of bags produced
    bagsCount = 0
    bagsRow = inventoryDisplay.filter(datetoday=dateNow)

    # Calculates the total number of bags produced on the day
    for bags in bagsRow:
        bagsCount += bags.noofbags

    # Shows the total commission
    totalCommission = bagsCount/5  # multiply by 0.2 (20 cents per bag)
    totalCommissionFloat = "{:.2f}".format(totalCommission)  # in string

    # Shows the total employees that attended on the day
    totalAttendanceEmployee = attendanceDisplay.filter(datetoday=dateNow).count()

    # Shows the individual commission
    if totalAttendanceEmployee != 0:
        individualCommission = "{:.2f}".format(totalCommission/totalAttendanceEmployee)  # in string
    else:
        individualCommission = "0.00"

    # Shows the different number of each type of product bags on different dates
    totalBasedcoat = []
    totalSkimcoat = []
    totalThinbed = []
    totalTilefix = []
    totalPlastering = []
    totalScreeding = []
    totalTileadhesive = []
    totalBrickjoint = []

    # Stores the number of employees on different dates
    totalEmployeeCount = []

    # Stores the total number of bags on different dates
    totalBagsDate = []

    # Stores the total commission on different dates
    totalAllCommission = []

    # To store all the different dates in the Inventorycount table
    inventoryProductDateAfter = []

    # Obtains all the different dates in the datetoday column in the Inventorycount table
    inventoryProductDateBefore = Inventorycount.objects.select_related('productid').values_list('datetoday', flat=True).distinct()

    # Puts all the different dates into an array
    for inventoryProductDate in inventoryProductDateBefore:
        inventoryProductDateAfter.append(inventoryProductDate)

    # Removes today's date if date appears in total bags column in Inventorycount table but is yet to be saved into the commission table
    if inventoryDisplay.filter(datetoday=dateNow).exists():
        if not Commission.objects.filter(currentdate=dateNow).exists():
            inventoryProductDateAfter.pop()

    # Obtains the number of different product bags and appending the values into arrays designated for each product bag, and calculating the total number of bags for different dates
    for date in inventoryProductDateAfter:
        # Checks whether the date is today
        if date != dateNow:
            # Filters for the number of different product bags on different dates
            basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date)[0].noofbags
            skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date)[0].noofbags
            thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date)[0].noofbags
            tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date)[0].noofbags
            plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date)[0].noofbags
            screedingDate = inventoryDisplay.filter(productid='7', datetoday=date)[0].noofbags
            tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date)[0].noofbags
            brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date)[0].noofbags

            # Counts the total bags produced in the day
            totalBags = basedcoatDate + skimcoatDate + thinbedDate + tilefixDate + plasteringDate + screedingDate + tileadhesiveDate + brickjointDate
        else:
            # Counts the total bags produced in the day
            totalBags = round(Commission.objects.select_related('userid').all().filter(currentdate=dateNow)[0].amountpaid * totalAttendanceEmployee * 5)

            # Checks whether the total bags are the same
            if totalBags != bagsCount:
                # Shows message that the number of different product bags are pending save
                basedcoatDate = skimcoatDate = thinbedDate = tilefixDate = plasteringDate = screedingDate = tileadhesiveDate = brickjointDate = "Pending Save"
            else:
                # Filters for the number of different product bags on today's date
                basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date)[0].noofbags
                skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date)[0].noofbags
                thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date)[0].noofbags
                tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date)[0].noofbags
                plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date)[0].noofbags
                screedingDate = inventoryDisplay.filter(productid='7', datetoday=date)[0].noofbags
                tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date)[0].noofbags
                brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date)[0].noofbags

        # Filters for the number of employees on different dates
        employeeCount = attendanceDisplay.filter(datetoday=date).count()

        # Obtains the individual commission values from the Commission table on different dates
        allDateCommission = Commission.objects.filter(currentdate=date).values('amountpaid')
        
        # Calculates the total commission on different dates
        for commission in allDateCommission:
            allCommission = "{:.2f}".format(commission['amountpaid'] * employeeCount)

        # Rounds off the coins to the first closest decimal before changing back to two decimals if the coins do not end at 0 or 5 cents
        if allCommission[-1] != 5 and allCommission[-1] != 0:
            allCommission = "{:.1f}".format(float(allCommission))
            allCommission = "{:.2f}".format(float(allCommission))

        # Appends into the arrays from the right
        totalBasedcoat.insert(0, basedcoatDate)
        totalSkimcoat.insert(0, skimcoatDate)
        totalThinbed.insert(0, thinbedDate)
        totalTilefix.insert(0, tilefixDate)
        totalPlastering.insert(0, plasteringDate)
        totalScreeding.insert(0, screedingDate)
        totalTileadhesive.insert(0, tileadhesiveDate)
        totalBrickjoint.insert(0, brickjointDate)
        totalEmployeeCount.insert(0, employeeCount)
        totalBagsDate.insert(0, totalBags)
        totalAllCommission.insert(0, allCommission)

    return render(request, 'commission.html', {'DateNow': dateNow,
                                               'CommissionTable': commissionDisplay,
                                               'BagsCount': bagsCount,
                                               'TotalCommission': totalCommissionFloat,
                                               'IndividualCommission': individualCommission,
                                               'TotalBasedcoat': totalBasedcoat,
                                               'TotalSkimcoat': totalSkimcoat,
                                               'TotalThinbed': totalThinbed,
                                               'TotalTilefix': totalTilefix,
                                               'TotalPlastering': totalPlastering,
                                               'TotalScreeding': totalScreeding,
                                               'TotalTileadhesive': totalTileadhesive,
                                               'TotalBrickjoint': totalBrickjoint,
                                               'TotalEmployeeCount': totalEmployeeCount,
                                               'TotalBagsDate': totalBagsDate,
                                               'TotalAllCommission': totalAllCommission})


# Button to save the daily commission into the AWS database Commission table
@login_required
def save_commission(request):
    # Today's date
    dateNow = d.today()

    # First check if the employees have checked in their attendance today
    if totalAttendanceEmployee == 0:
        # Deletes today's inserted row in the Commission table if all the employee's attendance has been removed
        if Commission.objects.filter(currentdate=dateNow).exists():
            commission_today = Commission.objects.get(currentdate=dateNow)
            commission_today.delete()

            messages.success(request, "Daily commission succesfully saved!")
        else:
            # Shows an error message
            messages.error(request, "Please check in your attendance!")

        return redirect("commission")
    # Then check if product bags are recorded in the inventory today
    elif bagsCount == 0:
        # Deletes today's inserted row in the Commission table if the all the inserted items into the inventorycount table has been removed
        if Commission.objects.filter(currentdate=dateNow).exists():
            commission_today = Commission.objects.get(currentdate=dateNow)
            commission_today.delete()

            messages.success(request, "Daily commission succesfully saved!")
        else:
            # Shows an error message
            messages.error(request, "No bags produced today!")

        return redirect("commission")
    else:
        # Updates (Does not insert) row when today's row has been generated
        if Commission.objects.filter(currentdate=dateNow).exists():
            commission_today = Commission.objects.get(currentdate=dateNow)
            commission_today.amountpaid = individualCommission
            commission_today.save()
        else:
            saveCommission = Commission(currentdate=dateNow, amountpaid=individualCommission)
            saveCommission.save()
            
        messages.success(request, "Daily commission succesfully saved!")

        return redirect("commission")


# Commission Search Page
@login_required
def search_commission(request):
    # Today's date
    dateNow = d.today()
    
    # Obtains data from database tables
    inventoryDisplay = Inventorycount.objects.select_related('productid').all()
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Shows the daily number of bags produced
    bagsNumber = 0
    bagsRow = inventoryDisplay.filter(datetoday=dateNow)

    # Calculates the total number of bags produced on the day
    for bags in bagsRow:
        bagsNumber += bags.noofbags

    # Obtains the total employees that attended on the day
    totalSearchAttendanceEmployee = attendanceDisplay.filter(datetoday=dateNow).count()

    # Stores the different number of each type of product bags on different dates
    totalBasedcoat = []
    totalSkimcoat = []
    totalThinbed = []
    totalTilefix = []
    totalPlastering = []
    totalScreeding = []
    totalTileadhesive = []
    totalBrickjoint = []

    # Stores the number of employees on different dates
    totalEmployeeCount = []

    # Stores the total number of bags on different dates
    totalBagsDate = []

    # Stores the total commission on different dates
    totalAllCommission = []

    # Runs when a date is selected in the calendar searchbar
    if request.method == "POST":
        # Stores the dates in the commission table
        searchCommissionDate= []

        # Stores the dates in the inventorycount table
        searchInventoryDate = []

        # Stores the common dates in the two arrays
        searchDate = []

        # Obtains the data in the calendar searchbar
        commissionSearchDate = request.POST['commission_searchDate']

        # Checks for empty calendar searchbar
        if commissionSearchDate == "":
            return redirect("commission")

        # Filters for the rows in commission table with searched dates in the calendar searchbar
        commissionSearchedDate = Commission.objects.filter(currentdate__icontains=commissionSearchDate).order_by("-currentdate")

        # Obtains all the different dates in the datetoday column in the inventorycount table
        inventorySearchedDate = Inventorycount.objects.select_related('productid').values_list('datetoday', flat=True).distinct()

        # Obtains the dates from the searched rows and appends them into an array
        for row in commissionSearchedDate:
            searchCommissionDate.append(row.currentdate)

        # Obtains the dates from the commission table in the database
        for date in inventorySearchedDate:
            searchInventoryDate.append(date)

        # Compares the two arrays above and obtains an array with the same dates
        searchDate = list(set(searchCommissionDate).intersection(searchInventoryDate))

        # Arranges the dates in the array
        searchDate.sort()

        # Obtains the number of different product bags and appending the values into arrays designated for each product bag
        for inventoryProductDate in searchDate:
            # Checks whether the date is today
            if inventoryProductDate != dateNow:
                # Filters for the number of different product bags on different dates
                basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=inventoryProductDate)[0].noofbags
                skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=inventoryProductDate)[0].noofbags
                thinbedDate = inventoryDisplay.filter(productid='4', datetoday=inventoryProductDate)[0].noofbags
                tilefixDate = inventoryDisplay.filter(productid='5', datetoday=inventoryProductDate)[0].noofbags
                plasteringDate = inventoryDisplay.filter(productid='6', datetoday=inventoryProductDate)[0].noofbags
                screedingDate = inventoryDisplay.filter(productid='7', datetoday=inventoryProductDate)[0].noofbags
                tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=inventoryProductDate)[0].noofbags
                brickjointDate = inventoryDisplay.filter(productid='9', datetoday=inventoryProductDate)[0].noofbags

                # Counts the total bags produced in the day
                totalBags = basedcoatDate + skimcoatDate + thinbedDate + tilefixDate + plasteringDate + screedingDate + tileadhesiveDate + brickjointDate
            else:
                # Counts the total bags produced in the day
                totalBags = round(Commission.objects.select_related('userid').all().filter(currentdate=dateNow)[0].amountpaid * totalSearchAttendanceEmployee * 5)

                # Checks whether the total bags are the same
                if totalBags != bagsNumber:
                    # Shows message that the number of different product bags are pending save
                    basedcoatDate = skimcoatDate = thinbedDate = tilefixDate = plasteringDate = screedingDate = tileadhesiveDate = brickjointDate = "Pending Save"
                else:
                    # Filters for the number of different product bags on today's date
                    basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=inventoryProductDate)[0].noofbags
                    skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=inventoryProductDate)[0].noofbags
                    thinbedDate = inventoryDisplay.filter(productid='4', datetoday=inventoryProductDate)[0].noofbags
                    tilefixDate = inventoryDisplay.filter(productid='5', datetoday=inventoryProductDate)[0].noofbags
                    plasteringDate = inventoryDisplay.filter(productid='6', datetoday=inventoryProductDate)[0].noofbags
                    screedingDate = inventoryDisplay.filter(productid='7', datetoday=inventoryProductDate)[0].noofbags
                    tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=inventoryProductDate)[0].noofbags
                    brickjointDate = inventoryDisplay.filter(productid='9', datetoday=inventoryProductDate)[0].noofbags
            
            # Filters for the number of employees on different dates
            employeeCount = attendanceDisplay.filter(datetoday=inventoryProductDate).count()

            # Obtains the individual commission values from the Commission table on different dates
            allDateCommission = Commission.objects.filter(currentdate=inventoryProductDate).values('amountpaid')
            
            # Calculates the total commission on different dates
            for commission in allDateCommission:
                allCommission = "{:.2f}".format(commission['amountpaid'] * employeeCount)

            # Rounds off the coins to the first closest decimal before changing back to two decimals if the coins do not end at 0 or 5 cents
            if allCommission[-1] != 5 and allCommission[-1] != 0:
                allCommission = "{:.1f}".format(float(allCommission))
                allCommission = "{:.2f}".format(float(allCommission))

            # Appends into the arrays from the right
            totalBasedcoat.insert(0, basedcoatDate)
            totalSkimcoat.insert(0, skimcoatDate)
            totalThinbed.insert(0, thinbedDate)
            totalTilefix.insert(0, tilefixDate)
            totalPlastering.insert(0, plasteringDate)
            totalScreeding.insert(0, screedingDate)
            totalTileadhesive.insert(0, tileadhesiveDate)
            totalBrickjoint.insert(0, brickjointDate)
            totalEmployeeCount.insert(0, employeeCount)
            totalBagsDate.insert(0, totalBags)
            totalAllCommission.insert(0, allCommission)

        return render(request, 'commission_search.html', {'CommissionTable': commissionSearchedDate,
                                                          'TotalSearchAttendanceEmployee': totalSearchAttendanceEmployee,
                                                          'TotalBasedcoat': totalBasedcoat,
                                                          'TotalSkimcoat': totalSkimcoat,
                                                          'TotalThinbed': totalThinbed,
                                                          'TotalTilefix': totalTilefix,
                                                          'TotalPlastering': totalPlastering,
                                                          'TotalScreeding': totalScreeding,
                                                          'TotalTileadhesive': totalTileadhesive,
                                                          'TotalBrickjoint': totalBrickjoint,
                                                          'TotalEmployeeCount': totalEmployeeCount,
                                                          'TotalBagsDate': totalBagsDate,
                                                          'TotalAllCommission': totalAllCommission,
                                                          'CommissionTitle': commissionSearchDate})

# Employee Commission Page View
@login_required
def commission_employee(request):
    # Today's date
    dateNow = d.today()
    monthNow = dateNow.month
    monthNowAlpha = dateNow.strftime("%B")
    yearNow = dateNow.year

    # Obtains data from database tables
    commissionDisplay = Commission.objects.select_related('userid').all()
    inventoryDisplay = Inventorycount.objects.select_related('productid').all()
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Updates the previous Commission table entry if it is not updated (Button not saved)
    # Checks whether there is an entry in the Commission table
    if commissionDisplay.last() != "":
        # Obtains the date of the last entry in the Commission table
        commissionDateUpdateCheck = commissionDisplay.values_list('currentdate', flat=True).last()

        # Checks if the date of the last entry in the Commission table is the current date
        if commissionDateUpdateCheck != dateNow:
            # Contains the total bags made on the previous day
            bagsPrevious = 0

            # Obtains the rows of different product bags made on the previous day
            inventoryTotalPrevious = inventoryDisplay.filter(datetoday=commissionDateUpdateCheck)

            # Calculates the total bags made on the previous day
            for bags in inventoryTotalPrevious:
                bagsPrevious += bags.noofbags

            # Obtains the total attendance on the previous day
            attendancePrevious = attendanceDisplay.filter(datetoday=commissionDateUpdateCheck).count()

            # Calculates the actual updated individual commission amount
            commissionSelfUpdate = "{:.2f}".format(bagsPrevious / 5 / attendancePrevious)

            # Obtains the previous individual commission saved in the Commission table
            commissionUpdateCheck = commissionDisplay.values_list('amountpaid', flat=True).last()
            commissionUpdateCheck = str(commissionUpdateCheck)

            # Checks if the individual commission of the previous entry is correct
            if commissionSelfUpdate != commissionUpdateCheck:
                # Saves the updated commission to the previous date
                if Commission.objects.filter(currentdate=commissionDateUpdateCheck).exists():
                    commissionUpdate = Commission.objects.get(currentdate=commissionDateUpdateCheck)
                    commissionUpdate.amountpaid = commissionSelfUpdate
                    commissionUpdate.save()

    # Obtains data from the updated database tables
    commissionDisplay = Commission.objects.select_related('userid').all()
    inventoryDisplay = Inventorycount.objects.select_related('productid').all()
    attendanceDisplay = Attendance.objects.select_related('userid').all()

    # Global Attributes
    global bagsTotal
    global commissionSelf
    global attendanceTotal

    # Shows the daily number of bags produced
    bagsTotal = 0
    bagsRow = inventoryDisplay.filter(datetoday=dateNow)

    # Calculates the total number of bags produced on the day
    for bags in bagsRow:
        bagsTotal += bags.noofbags

    # Shows the total commission
    commissionTotal = bagsTotal/5  # multiply by 0.2 (20 cents per bag)
    commissionTotalFloat = "{:.2f}".format(commissionTotal)  # in string

    # Shows the total employees that attended on the day
    attendanceTotal = attendanceDisplay.filter(datetoday=dateNow).count()

    # Shows the individual commission
    if attendanceTotal != 0:
        commissionSelf = "{:.2f}".format(commissionTotal/attendanceTotal)  # in string
    else:
        commissionSelf = "0.00"

    # Stores the dates that the workers have worked
    dateWork = []

    # Obtains the ID of the employee logged in
    userCurrent = request.user

    # Runs when the month and year are selected in the calendar searchbar
    if request.method == "POST":
        # Obtains the data in the calendar searchbar
        commissionSearchMonth = request.POST['commission_searchMonth']

        # Checks for empty calendar searchbar
        if commissionSearchMonth == "":
            return redirect("commission_employee")

        # Splits the data into year and month
        yearSearch = commissionSearchMonth.split("-")[0]
        monthSearch = commissionSearchMonth.split("-")[1]

        # Obtains the rows from the Attendance table based on the employee logged in and the attendance made in the searched year and month
        attendanceUser = attendanceDisplay.filter(userid=userCurrent, datetoday__year=yearSearch, datetoday__month=monthSearch)

        # Shows the searched year and month
        yearNow = yearSearch
        monthNowAlpha = calendar.month_name[int(monthSearch)]
    else:
        # Obtains the rows from the Attendance table based on the employee logged in and the attendance made in the current year and month
        attendanceUser = attendanceDisplay.filter(userid=userCurrent, datetoday__year=yearNow, datetoday__month=monthNow)

    # Obtains the dates of when the specific employee attended work in the current month
    for dates in attendanceUser:
        dateWork.append(dates.datetoday)

    # Obtains the rows from the Commission table based on the dates the specific employee attended work in the current month
    commissionUser = commissionDisplay.filter(currentdate__in=dateWork).order_by("-currentdate")

    # Initialises the total commission the specific employee earned in the current month
    commissionSelfMonth = 0

    # Calculates the total commission the specific employee earned in the current month
    for commission in commissionUser:
        commissionSelfMonth += commission.amountpaid

    # Displays 0 in two-decimal form
    if commissionSelfMonth == 0:
        commissionSelfMonth = "0.00"

    # Shows the different number of each type of product bags on different dates
    basedcoatTotal = []
    skimcoatTotal = []
    thinbedTotal = []
    tilefixTotal = []
    plasteringTotal = []
    screedingTotal = []
    tileadhesiveTotal = []
    brickjointTotal = []

    # Stores the number of employees on different dates
    employeeTotalDate = []

    # Stores the total number of bags on different dates
    bagsTotalDate = []

    # Stores the total commission on different dates
    commissionTotalDate = []

    # To store the different dates in the current month in Inventorycount table which the worker worked
    DateInventorycount = []

    # Obtains the different dates in the current month in the datetoday column in the Inventorycount table which the worker worked
    DateInventorycountAll = Inventorycount.objects.select_related('productid').values_list('datetoday', flat=True).filter(datetoday__in=dateWork).distinct()

    # Puts the different dates into an array
    for dates in DateInventorycountAll:
        DateInventorycount.append(dates)

    # Removes today's date if date appears in total bags column in Inventorycount table but is yet to be saved into the commission table and current day is a working day
    if inventoryDisplay.filter(datetoday=dateNow).exists() and not Commission.objects.filter(currentdate=dateNow).exists() and dateNow in dateWork:
        DateInventorycount.pop()

    # Obtains the number of different product bags and appending the values into arrays designated for each product bag, and calculating the total number of bags for different dates
    for date in DateInventorycount:
        # Checks whether the date is today
        if date != dateNow:
            # Filters for the number of different product bags on different dates
            basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date)[0].noofbags
            skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date)[0].noofbags
            thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date)[0].noofbags
            tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date)[0].noofbags
            plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date)[0].noofbags
            screedingDate = inventoryDisplay.filter(productid='7', datetoday=date)[0].noofbags
            tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date)[0].noofbags
            brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date)[0].noofbags

            # Counts the total bags produced in the day
            totalBags = basedcoatDate + skimcoatDate + thinbedDate + tilefixDate + plasteringDate + screedingDate + tileadhesiveDate + brickjointDate
        else:
            # Counts the total bags produced in the day
            totalBags = round(Commission.objects.select_related('userid').all().filter(currentdate=dateNow)[0].amountpaid * attendanceTotal * 5)

            # Checks whether the total bags are the same
            if totalBags != bagsTotal:
                # Shows message that the number of different product bags are pending save
                basedcoatDate = skimcoatDate = thinbedDate = tilefixDate = plasteringDate = screedingDate = tileadhesiveDate = brickjointDate = "Pending Save"
            else:
                # Filters for the number of different product bags on today's date
                basedcoatDate = inventoryDisplay.filter(productid='1', datetoday=date)[0].noofbags
                skimcoatDate = inventoryDisplay.filter(productid='2', datetoday=date)[0].noofbags
                thinbedDate = inventoryDisplay.filter(productid='4', datetoday=date)[0].noofbags
                tilefixDate = inventoryDisplay.filter(productid='5', datetoday=date)[0].noofbags
                plasteringDate = inventoryDisplay.filter(productid='6', datetoday=date)[0].noofbags
                screedingDate = inventoryDisplay.filter(productid='7', datetoday=date)[0].noofbags
                tileadhesiveDate = inventoryDisplay.filter(productid='8', datetoday=date)[0].noofbags
                brickjointDate = inventoryDisplay.filter(productid='9', datetoday=date)[0].noofbags

        # Filters for the number of employees on different dates
        employeeCount = attendanceDisplay.filter(datetoday=date).count()

        # Obtains the individual commission values from the Commission table on different dates
        allDateCommission = Commission.objects.filter(currentdate=date).values('amountpaid')
        
        # Calculates the total commission on different dates
        for commission in allDateCommission:
            allCommission = "{:.2f}".format(commission['amountpaid'] * employeeCount)

        # Rounds off the coins to the first closest decimal before changing back to two decimals if the coins do not end at 0 or 5 cents
        if allCommission[-1] != 5 and allCommission[-1] != 0:
            allCommission = "{:.1f}".format(float(allCommission))
            allCommission = "{:.2f}".format(float(allCommission))

        # Appends into the arrays from the right
        basedcoatTotal.insert(0, basedcoatDate)
        skimcoatTotal.insert(0, skimcoatDate)
        thinbedTotal.insert(0, thinbedDate)
        tilefixTotal.insert(0, tilefixDate)
        plasteringTotal.insert(0, plasteringDate)
        screedingTotal.insert(0, screedingDate)
        tileadhesiveTotal.insert(0, tileadhesiveDate)
        brickjointTotal.insert(0, brickjointDate)
        employeeTotalDate.insert(0, employeeCount)
        bagsTotalDate.insert(0, totalBags)
        commissionTotalDate.insert(0, allCommission)

    # Changes colour and disables the button if the worker's attendance is not registered
    if not attendanceDisplay.filter(userid=userCurrent, datetoday=dateNow).exists():
        commissionNumbers = "commission_numbers_disable"
        commissionSave = "commission_save_disable"
        commissionSaveButton = "commission_save_button_disable"
    else:
        commissionNumbers = "commission_numbers"
        commissionSave = "commission_save"
        commissionSaveButton = "commission_save_button"
    
    return render(request, 'commission_employee.html', {'DateNow': dateNow,
                                                        'BagsTotal': bagsTotal,
                                                        'CommissionTotalFloat': commissionTotalFloat,
                                                        'CommissionSelf': commissionSelf,
                                                        'MonthNowAlpha': monthNowAlpha,
                                                        'YearNow': yearNow,
                                                        'CommissionSelfMonth': commissionSelfMonth,
                                                        'CommissionTable': commissionUser,
                                                        'BasedcoatTotal': basedcoatTotal,
                                                        'SkimcoatTotal': skimcoatTotal,
                                                        'ThinbedTotal': thinbedTotal,
                                                        'TilefixTotal': tilefixTotal,
                                                        'PlasteringTotal': plasteringTotal,
                                                        'ScreedingTotal': screedingTotal,
                                                        'TileadhesiveTotal': tileadhesiveTotal,
                                                        'BrickjointTotal': brickjointTotal,
                                                        'EmployeeTotalDate': employeeTotalDate,
                                                        'BagsTotalDate': bagsTotalDate,
                                                        'CommissionTotalDate': commissionTotalDate,
                                                        'CommissionNumbers': commissionNumbers,
                                                        'CommissionSave': commissionSave,
                                                        'CommissionSaveButton': commissionSaveButton})

# Button to save the daily commission into the AWS database Commission table (Employee)
@login_required
def commission_employee_save(request):
    # Today's date
    dateNow = d.today()

    # First check if the employees have checked in their attendance today
    if attendanceTotal == 0:
        # Deletes today's inserted row in the Commission table if all the employee's attendance has been removed
        if Commission.objects.filter(currentdate=dateNow).exists():
            commission_today = Commission.objects.get(currentdate=dateNow)
            commission_today.delete()

            messages.success(request, "Daily commission succesfully saved!")
        else:
            # Shows an error message
            messages.error(request, "Please check in your attendance!")

        return redirect("commission_employee")
    # Then check if product bags are recorded in the inventory today
    elif bagsTotal == 0:
        # Deletes today's inserted row in the Commission table if the all the inserted items into the inventorycount table has been removed
        if Commission.objects.filter(currentdate=dateNow).exists():
            commission_today = Commission.objects.get(currentdate=dateNow)
            commission_today.delete()

            messages.success(request, "Daily commission succesfully saved!")
        else:
            # Shows an error message
            messages.error(request, "No bags produced today!")

        return redirect("commission_employee")
    else:
        # Updates (Does not insert) row when today's row has been generated
        if Commission.objects.filter(currentdate=dateNow).exists():
            commission_today = Commission.objects.get(currentdate=dateNow)
            commission_today.amountpaid = commissionSelf
            commission_today.save()
        else:
            saveCommission = Commission(currentdate=dateNow, amountpaid=commissionSelf)
            saveCommission.save()
            
        messages.success(request, "Daily commission succesfully saved!")

        return redirect("commission_employee")