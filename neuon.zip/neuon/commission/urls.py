from django.urls import path
from . import views

urlpatterns = [
    path('commission', views.commission, name='commission'),
    path('save_commission', views.save_commission, name='save_commission'),
    path('search_commission', views.search_commission, name='search_commission'),
    path('commission_employee', views.commission_employee, name='commission_employee'),
    path('commission_employee_save', views.commission_employee_save, name='commission_employee_save'),
]