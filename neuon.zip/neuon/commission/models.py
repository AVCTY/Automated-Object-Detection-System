from django.db import models
from accounts.models import User

# Create your models here.
class Commission(models.Model):
    commissionid = models.AutoField(db_column='commissionID', primary_key=True)  # Field name made lowercase.
    userid = models.ForeignKey(User, models.DO_NOTHING, db_column='userID', blank=True, null=True)  # Field name made lowercase.
    currentdate = models.DateField(blank=True, null=True)
    amountpaid = models.DecimalField(db_column='amountPaid', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Commission'