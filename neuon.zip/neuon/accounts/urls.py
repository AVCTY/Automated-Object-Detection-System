from django.urls import path
from . import views

urlpatterns = [
    path("login/", views.login, name="login"),
    path("register/", views.register, name="register"),
    path("edit_user/", views.edit_user, name="edit_user"),
    path("deactivate_user/", views.deactivate_user, name="deactivate_user"),
    path("logout/", views.logout, name="logout"),
    path("users/", views.users, name="users"),
]