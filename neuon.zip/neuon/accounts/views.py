from django.shortcuts import render, redirect
from .models import User
from home.views import home
from django.contrib.auth.models import auth
from django.contrib.auth.decorators import user_passes_test
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.
def login_excluded(redirect_to):
    """ This decorator kicks authenticated users out of a view """ 
    def _method_wrapper(view_method):
        def _arguments_wrapper(request, *args, **kwargs):
            if request.user.is_authenticated:
                return redirect(redirect_to) 
            return view_method(request, *args, **kwargs)
        return _arguments_wrapper
    return _method_wrapper


@login_required
@user_passes_test(lambda u: u.is_admin)
def users(request):
    data = User.objects.select_related().all()
    return render(request, "users.html", {"data":data})


@login_required
@user_passes_test(lambda u: u.is_admin)
def register(request):
    if request.method == "POST":
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        email = request.POST["email"]
        phone_number = request.POST["phone_number"]
        username = request.POST["username"]
        password = request.POST["password"]
        role = request.POST["role"]

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username is taken!")
            return redirect("register")
        elif User.objects.filter(email=email).exists():
            messages.error(request, "Email is already in use!")
            return redirect("register")
        else:
            if role == "admin" or role == "Admin" or role == "ADMIN":
                user = User.objects.create_superuser(username=username, first_name=first_name, last_name=last_name, email=email, phone_number=phone_number, password=password)
                user.save()
                messages.success(request, "User Created")
                return redirect("register")
            elif role == "manager" or role == "Manager" or role == "MANAGER":
                user = User.objects.create_manager(username=username, first_name=first_name, last_name=last_name, email=email, phone_number=phone_number, password=password)
                user.save()
                messages.success(request, "User Created")
                return redirect("register")
            elif role == "employee" or role == "Employee" or role == "EMPLOYEE":
                user = User.objects.create_employee(username=username, first_name=first_name, last_name=last_name, email=email, phone_number=phone_number, password=password)
                user.save()
                messages.success(request, "User Created")
                return redirect("register")

    else:
        return render(request, "register.html")


@login_required
@user_passes_test(lambda u: u.is_admin)
def edit_user(request):
    err = 0
    if request.method == "POST":
        userid = request.POST["userid"]
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        email = request.POST["email"]
        phone_number = request.POST["phone_number"]
        username = request.POST["username"]
        password = request.POST["password"]
        role = request.POST["role"]

        # get user instance by id
        if User.objects.filter(pk=userid).exists():
            user = User.objects.get(pk=userid)

            if first_name != "":
                user.first_name = first_name

            if last_name != "":
                user.last_name = last_name

            if len(email) > 0:
                if User.objects.filter(email=email).exists():
                    err += 1
                else:
                    user.email = email

            if phone_number != "":
                user.phone_number = phone_number

            if username != "":
                if User.objects.filter(username=username).exists():
                    err += 1
                else:
                    user.username = username

            if password != "":
                user.password = password

            if role != "":
                if role == "admin" or role == "Admin" or role == "ADMIN":
                    user.admin = True
                    user.manager = True
                    user.employee = True
                elif role == "manager" or role == "Manager" or role == "MANAGER":
                    user.admin = False
                    user.manager = True
                    user.employee = False
                elif role == "employee" or role == "Employee" or role == "EMPLOYEE":
                    user.admin = False
                    user.manager = False
                    user.employee = True
                else:
                    err += 1


            # checking for errors
            if err == 0:
                user.save()
                messages.success(request, "User details updated!")
                return redirect("edit_user")
            elif err > 0:
                messages.error(request, "Email or Username is taken, or invalid Role!")
                return redirect("edit_user")
        else:
            messages.error(request, "User does not exist!")
            return redirect("edit_user")
    else:
        return render(request, "edituser.html")


@login_required
@user_passes_test(lambda u: u.is_admin)
def remove_user(request):
    data = User.objects.select_related().all()

    if request.method == "POST":
        userid = request.POST["userid"]

        if User.objects.filter(pk=userid).exists():
            user = User.objects.get(pk=userid)
            user.delete()
            messages.success(request, "User has been deleted!")
            return redirect("remove_user")
        else:
            messages.error(request, "User not found!")
            return redirect("remove_user")
    else:
        return render(request, "removeusers.html", {"data":data})


@login_excluded(home)
def login(request):
    if request.method == "POST":
        fUsername = request.POST["username"]
        fPassword = request.POST["password"]

        user = auth.authenticate(username=fUsername, password=fPassword)

        if user is not None:
            auth.login(request, user)
            return redirect("/")
        else:
            messages.error(request, "Invalid Credentials!")
            return redirect("login")
    else:
        return render(request, "login.html")


def logout(request):
    auth.logout(request)
    return redirect("login")