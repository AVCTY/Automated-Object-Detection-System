from django.shortcuts import render, redirect
from .models import User
from home.views import home
from django.contrib.auth.models import auth
from django.contrib.auth.decorators import user_passes_test
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Function to prevent logged in users from accessing login page without logging out.
def login_excluded(redirect_to):
    """ This decorator kicks authenticated users out of a view """ 
    def _method_wrapper(view_method):
        def _arguments_wrapper(request, *args, **kwargs):
            if request.user.is_authenticated: # checks if user is authenticated
                return redirect(redirect_to) # redirects user to specific pages
            return view_method(request, *args, **kwargs)
        return _arguments_wrapper
    return _method_wrapper


@login_required
@user_passes_test(lambda u: u.is_admin) # checks if user has admin permissions
def users(request):
    data = User.objects.select_related().all() # gets all user records

    # Shows back button
    searchMode = False

    # Search module
    if request.method == "POST":
        usersSearchUsernameId = request.POST.get('users_searchUsernameId')
        searchMode = True

        # Checks for empty searchbar
        if usersSearchUsernameId == "":
            return redirect("users")

        # Checks for the User ID and username with numbers
        if usersSearchUsernameId.isdigit():
            usersID = []
            usersSearchID = User.objects.filter(id__icontains=usersSearchUsernameId)
            usersSearchUsernameWId = User.objects.filter(username__icontains=usersSearchUsernameId)
            
            for row in usersSearchID:
                usersID.append(row.id)
            for row in usersSearchUsernameWId:
                usersID.append(row.id)

            usersID = list(set(usersID))

            data = User.objects.filter(id__in=usersID)
        # Checks for the User Username with letters, or both letters and numbers
        elif usersSearchUsernameId.isalpha() or usersSearchUsernameId.isalnum():
            usersUsername = []
            usersSearchUsername = User.objects.filter(username__icontains=usersSearchUsernameId)

            for row in usersSearchUsername:
                usersUsername.append(row.username)

            data = User.objects.filter(username__in=usersUsername)
        else:
            return redirect("users")

    return render(request, "users.html", {"data":data, 'SearchMode':searchMode})


@login_required
@user_passes_test(lambda u: u.is_admin) # checks if user has admin permissions
def register(request):
    if request.method == "POST":
        # get user credential inputs from form request
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        email = request.POST["email"]
        phone_number = request.POST["phone_number"]
        username = request.POST["username"]
        password = request.POST["password"]
        role = request.POST["role"]

        if User.objects.filter(username=username).exists(): # check if username exists
            messages.error(request, "Username is taken!") # throws error if username is already taken
            return redirect("register")
        elif User.objects.filter(email=email).exists(): # check if email exists
            messages.error(request, "Email is already in use!") # throws error message if email is already taken
            return redirect("register")
        else:
            # checks selected role and create and save user based on the roles
            if role == "admin":
                # create super user with admin level permissions
                user = User.objects.create_superuser(username=username, first_name=first_name, last_name=last_name, email=email, phone_number=phone_number, password=password)
                user.save() # saves user to database
                messages.success(request, "User Created") # throws success message
                return redirect("register")
            elif role == "manager":
                # create user with manager level permissions
                user = User.objects.create_manager(username=username, first_name=first_name, last_name=last_name, email=email, phone_number=phone_number, password=password)
                user.save() # saves user to database
                messages.success(request, "User Created") # throws success message
                return redirect("register")
            elif role == "employee":
                # create user with employee level permissions
                user = User.objects.create_employee(username=username, first_name=first_name, last_name=last_name, email=email, phone_number=phone_number, password=password)
                user.save() # saves user to database
                messages.success(request, "User Created") # throws success message
                return redirect("register")

    else:
        return render(request, "register.html")


@login_required
@user_passes_test(lambda u: u.is_admin) # checks if user has admin permissions
def edit_user(request):
    err = 0
    if request.method == "POST":
        # get user credential inputs from form request
        userid = request.POST["userid"]
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        email = request.POST["email"]
        phone_number = request.POST["phone_number"]
        username = request.POST["username"]
        password = request.POST["password"]
        role = request.POST["role"]

        # get user instance by id
        if User.objects.filter(pk=userid).exists(): # check if user exists
            user = User.objects.get(pk=userid) # get user by id

            # update user details if input fields are not empty
            if first_name != "": # checks if given first name is not empty
                user.first_name = first_name # updates first name with given value

            if last_name != "": # checks if given last name is not empty
                user.last_name = last_name # updates last name with given value

            if len(email) > 0: # checks for length of email field to see if it is empty 
                if User.objects.filter(email=email).exists(): # checks for if given email already exists in the database
                    err += 1 # throws back an error
                else:
                    user.email = email # if email is available and not taken, then update user's email to the new one given

            if phone_number != "": # checks if given phone number is not empty
                user.phone_number = phone_number # updates phone number with given value if not empty

            if username != "": # checks if username value is not empty
                if User.objects.filter(username=username).exists(): # checks if given username already exists in the database
                    err += 1 # throws back error if username is already taken
                else:
                    user.username = username # updates username with given value if it's not taken

            if password != "": # checks if password value is not empty
                user.password = password # updates password with given value
            
            if role != "":
                if role == "admin": # checks if role request is admin
                    # apply appropriate settings to admin level user
                    user.admin = True
                    user.manager = True
                    user.employee = True
                elif role == "manager": # checks if role request is manager
                    # apply appropriate settings to manager level user
                    user.admin = False
                    user.manager = True
                    user.employee = False
                elif role == "employee": # checks if role request is employee
                    # apply appropriate settings to employee level user
                    user.admin = False
                    user.manager = False
                    user.employee = True
                else:
                    err += 1


            # checking for errors
            if err == 0 and user != None:
                user.is_active = True
                user.save() # saves user details into database if there is no error
                messages.success(request, "User details updated!") # throws success message
                return redirect("edit_user") # redirect back to edit users page
            elif err > 0 or user == None:
                messages.error(request, "Email or Username is taken, Invalid Role, or Inactive User!") # throws error message if there is an error with user details
                return redirect("edit_user")
        else:
            messages.error(request, "User does not exist!") # throws error message for users that do not exist
            return redirect("edit_user")
    else:
        return render(request, "edituser.html")


@login_required
@user_passes_test(lambda u: u.is_admin) # checks if user has admin permissions
def deactivate_user(request):
    data = User.objects.select_related().all() # gets all records of users

    if request.method == "POST": # checks for form method
        userid = request.POST["userid"] # gets userid from form request

        if User.objects.filter(pk=userid).exists(): # checks if user exists by matching userid
            user = User.objects.get(pk=userid) # gets user
            # users who are let go or no longer work with the company should not be deleted from the database, however their access should be
            # restricted so that they cannot access the modules in the system
            user.is_active = False # sets user to inactive and updates database
            user.save()
            messages.success(request, "User's access has been restricted!") # throws success message
            return redirect("deactivate_user")
        else:
            messages.error(request, "User not found!") # throws error message if user doesn't exist
            return redirect("deactivate_user")
    else:
        return render(request, "removeusers.html", {"data":data})


# login function with credential authentication
@login_excluded(home)
def login(request):
    if request.method == "POST":
        fUsername = request.POST["username"] # get username from form request
        fPassword = request.POST["password"] # get password from form request

        user = auth.authenticate(username=fUsername, password=fPassword) # authenticating credentials

        if user is not None: # checks if user exists
            auth.login(request, user)
            return redirect("/")
        else:
            messages.error(request, "Invalid Credentials!") # throw error if credentials are wrong
            return redirect("login")
    else:
        return render(request, "login.html")


# log out function that checks if authenticated user is logged in then logs them out
def logout(request):
    auth.logout(request)
    return redirect("login")