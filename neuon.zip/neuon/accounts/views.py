from django.shortcuts import render, redirect
from .models import User
from home.views import home
from django.contrib.auth.models import auth
from django.contrib.auth.decorators import user_passes_test
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import re

# Function to prevent logged in users from accessing login page without logging out.
def login_excluded(redirect_to):
    """ This decorator kicks authenticated users out of a view """ 
    def _method_wrapper(view_method):
        def _arguments_wrapper(request, *args, **kwargs):
            if request.user.is_authenticated: # checks if user is authenticated
                return redirect(redirect_to) # redirects user to specific pages
            return view_method(request, *args, **kwargs)
        return _arguments_wrapper
    return _method_wrapper



@login_required
@user_passes_test(lambda u: u.is_admin or u.is_manager) # checks if user has admin or manager permissions
def users(request):
    data = User.objects.select_related().all() # gets all user records

    # Shows back button
    searchMode = False

    # Search module
    if request.method == "POST":
        usersSearchUsernameId = request.POST.get('users_searchUsernameId')
        searchMode = True

        # Checks for empty searchbar
        if usersSearchUsernameId == "":
            return redirect("users")

        # Checks for the User ID and username with numbers
        if usersSearchUsernameId.isdigit():
            usersID = []
            usersSearchID = User.objects.filter(id__icontains=usersSearchUsernameId)
            usersSearchUsernameWId = User.objects.filter(username__icontains=usersSearchUsernameId)
            
            for row in usersSearchID:
                usersID.append(row.id)
            for row in usersSearchUsernameWId:
                usersID.append(row.id)

            usersID = list(set(usersID))

            data = User.objects.filter(id__in=usersID)
        # Checks for the User Username with letters, or both letters and numbers
        elif usersSearchUsernameId.isalpha() or usersSearchUsernameId.isalnum():
            usersUsername = []
            usersSearchUsername = User.objects.filter(username__icontains=usersSearchUsernameId)

            for row in usersSearchUsername:
                usersUsername.append(row.username)

            data = User.objects.filter(username__in=usersUsername)
        else:
            return redirect("users")

    return render(request, "users.html", {"data":data, 'SearchMode':searchMode})



# function to update user from editable table
@login_required
@user_passes_test(lambda u: u.is_admin or u.is_manager) # checks if user has admin or manager permissions
@csrf_exempt
def update_user(request):
    err = 0 # set error count to 0 by default
    id = request.POST.get("id", "")
    type = request.POST.get("type", "")
    value = request.POST.get("value", "")
    response = None
    
    user = User.objects.get(pk=id) # get the user by user id
    
    if type == "first_name":
        user.first_name = value
        
    if type == "last_name":
        user.last_name = value
        
    if type == "email":
        regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        temp = re.search(regex, value)
        # checks if email exists
        if User.objects.filter(email=value).exists():
            err += 1 # gives error if there is already an existing email in the database
            response = JsonResponse({"message":"Email is taken!"})
            response.status_code = 403 # error to announce that user is not allowed to publish
        else:
            if temp:
                user.email = value
            else:
                err += 1 # gives error if there is already an existing email in the database
                response = JsonResponse({"message":"Wrong format for email!"})
                response.status_code = 403 # error to announce that user is not allowed to publish
            
    if type == "phone_number":
        pNo = re.search("^(\+?6?01)[02-46-9][-][0-9]{7,8}$|^(\+?6?01)[1][-][0-9]{7,8}$", value)
        if pNo:
            user.phone_number = value
        else:
            err += 1 # gives error if phone number does not match the pattern
            response = JsonResponse({"message":"Wrong format for the phone number!"})
            response.status_code = 403 # error to announce that user is not allowed to publish
        
    if type == "username":
        # checks if username exists
        if User.objects.filter(username=value).exists():
            err += 1 # gives error if there is already an existing username in the database
            response = JsonResponse({"message":"Username is taken!"})
            response.status_code = 403 # error to announce that user is not allowed to publish
        else:
            user.username = value
        
    if type == "status":
        if value == "Active":
            user.is_active = True
        elif value == "Inactive":
            user.is_active = False
        
    if type == "role":
        if value == "Admin":
            user.is_admin = True
            user.is_manager = True
            user.is_employee = True
        elif value == "Manager":
            user.is_admin = False
            user.is_manager = True
            user.is_employee = False
        elif value == "Employee":
            user.is_admin = False
            user.is_manager = False
            user.is_employee = True
    
    if type == "password":
        new_pass = value
        if user.check_password(new_pass): # checks if new password entered is the same as current password
            err += 1 # gives error if new password is the same as the current password
            response = JsonResponse({"message":"New password cannot be the same as the current one!"})
            response.status_code = 403 # error to announce that user is not allowed to publish
        else:
            user.set_password(new_pass)
            
            
    if err == 0:
        user.save()
        response = JsonResponse({"message":"Details are updated!"})
        return response
    elif err > 0:
        return response



@login_required
@user_passes_test(lambda u: u.is_admin or u.is_manager) # checks if user has admin or manager permissions
def register(request):
    if request.method == "POST":
        # get user credential inputs from form request
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        email = request.POST["email"]
        phone_number = request.POST["phone_number"]
        username = request.POST["username"]
        password = request.POST["password"]
        role = request.POST["role"]

        if User.objects.filter(username=username).exists(): # check if username exists
            messages.error(request, "Username is taken!") # throws error if username is already taken
            return redirect("register")
        elif User.objects.filter(email=email).exists(): # check if email exists
            messages.error(request, "Email is already in use!") # throws error message if email is already taken
            return redirect("register")
        else:
            # checks selected role and create and save user based on the roles
            if role == "admin":
                # create super user with admin level permissions
                user = User.objects.create_superuser(username=username, first_name=first_name, last_name=last_name, email=email, phone_number=phone_number, password=password)
                user.save() # saves user to database
                messages.success(request, "User Created") # throws success message
                return redirect("register")
            elif role == "manager":
                # create user with manager level permissions
                user = User.objects.create_manager(username=username, first_name=first_name, last_name=last_name, email=email, phone_number=phone_number, password=password)
                user.save() # saves user to database
                messages.success(request, "User Created") # throws success message
                return redirect("register")
            elif role == "employee":
                # create user with employee level permissions
                user = User.objects.create_employee(username=username, first_name=first_name, last_name=last_name, email=email, phone_number=phone_number, password=password)
                user.save() # saves user to database
                messages.success(request, "User Created") # throws success message
                return redirect("register")

    else:
        return render(request, "register.html")



# login function with credential authentication
@login_excluded(home)
def login(request):
    if request.method == "POST":
        fUsername = request.POST["username"] # get username from form request
        fPassword = request.POST["password"] # get password from form request

        user = auth.authenticate(username=fUsername, password=fPassword) # authenticating credentials

        if user is not None: # checks if user exists
            auth.login(request, user)
            return redirect("/")
        else:
            messages.error(request, "Invalid Credentials!") # throw error if credentials are wrong
            return redirect("login")
    else:
        return render(request, "login.html")


# log out function that checks if authenticated user is logged in then logs them out
def logout(request):
    auth.logout(request)
    return redirect("login")