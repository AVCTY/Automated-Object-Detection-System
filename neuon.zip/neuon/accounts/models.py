from django.db import models
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser
)

# Create your models here.
class UserManager(BaseUserManager):
    # default function to create a user taking in username, first name, last name, email, phone no, and password
    def create_user(self, username, first_name, last_name, email, phone_number, password=None):
        """
        Creates and saves a user with the given username and password
        """
        if not username:
            raise ValueError("Users must have a username")
        
        user = self.model(
            username=username,
        )

        user.first_name = first_name
        user.last_name = last_name
        user.email = email
        user.phone_number = phone_number
        user.set_password(password)
        user.save(using=self._db)
        return user

    # function to create super user with admin level permissions 
    def create_superuser(self, username, first_name, last_name, email, phone_number, password=None):
        """
        Creates and saves admin level superuser with the given username and password
        """
        user = self.create_user(
            username,
            first_name,
            last_name,
            email,
            phone_number,
            password
        )
        # set permission levels to true (all permissions are checked as super user can access all the modules)
        user.admin = True
        user.manager = True
        user.employee = True
        user.save(using=self._db)
        return user

    # function to create user with manager level permissions
    def create_manager(self, username, first_name, last_name, email, phone_number, password=None):
        """
        Creates and saves admin level non-superuser with the given username and password
        """
        user = self.create_user(
            username,
            first_name,
            last_name,
            email,
            phone_number,
            password
        )
        user.manager = True
        user.save(using=self._db)
        return user

    # function to create user with employee level permissions
    def create_employee(self, username, first_name, last_name, email, phone_number, password=None):
        """
        Creates and saves staff member with the given username and password
        """
        user = self.create_user(
            username,
            first_name,
            last_name,
            email,
            phone_number,
            password
        )
        user.employee = True
        user.save(using=self._db)
        return user


# User object model
class User(AbstractBaseUser):
    username = models.CharField(verbose_name='username', max_length=20, unique=True)
    first_name = models.CharField(verbose_name="first name", max_length=10)
    last_name = models.CharField(verbose_name="last name", max_length=10)
    email = models.EmailField(verbose_name='email address', max_length=255, unique=True)
    phone_number = models.CharField(verbose_name="phone number", max_length=15)
    is_active = models.BooleanField(default=True)
    admin = models.BooleanField(default=False) # a superuser/admin level user
    manager = models.BooleanField(default=False) # an manager level user
    employee = models.BooleanField(default=False) # employee level user

    objects = UserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['first_name', 'last_name', 'email', 'phone_number'] # username and password are required by default in Django's built in user model

    def get_full_name(self):
        # user is identified by username
        return self.username

    def get_short_name(self):
        # user is identified by username
        return self.username

    def __str__(self):
        return self.username

    
    # ========= permission checking functions =========
    def has_perm(self, perm, obj=None):
        "Does the user have specific permissions?"
        # yes, always
        return True

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app 'app_label'?"
        # yes, always
        return True

    @property
    def is_admin(self):
        "Is user a superuser?"
        return self.admin

    @property
    def is_manager(self):
        "Is user a admin level non-superuser?"
        return self.manager

    @property
    def is_employee(self):
        "Is user a member level staff?"
        return self.employee