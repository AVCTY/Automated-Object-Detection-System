from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('search_home', views.search_home, name='search_home'),
]