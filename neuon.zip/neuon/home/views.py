from django.shortcuts import render, redirect
from django.http import HttpResponse
from inventory.models import Product, Inventorycount
from django.contrib.auth.decorators import login_required
from django.db.models import Sum

# Create your views here.
@login_required
def home(request):
    data = Inventorycount.objects.select_related('productid').all().order_by('-datetoday')[:20]
    d = Inventorycount.objects.select_related('productid').all()

    basedcoat_count = d.filter(productid="1").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    brickjoint_count = d.filter(productid="9").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    plastering_count = d.filter(productid="6").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    screeding_count = d.filter(productid="7").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    skimcoat_count = d.filter(productid="2").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    thinbed_count = d.filter(productid="4").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    tileadhesive_count = d.filter(productid="8").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    tilefix_count = d.filter(productid="5").aggregate(TOTAL = Sum('noofbags'))['TOTAL']

    context = {
        'd':data,
        'basedcoat_count':basedcoat_count,
        'brickjoint_count':brickjoint_count,
        'plastering_count':plastering_count,
        'screeding_count':screeding_count,
        'skimcoat_count':skimcoat_count,
        'thinbed_count':thinbed_count,
        'tileadhesive_count':tileadhesive_count,
        'tilefix_count':tilefix_count,
    }

    return render(request, 'home.html', context)


@login_required
def search_home(request):
    # Runs when the search button is clicked
    if request.method == "POST":
        # Obtains the data in the searchbar
        home_search_inventory = request.POST['search_inventory']
    else:
        return redirect("home")

    # Checks for empty searchbar
    if home_search_inventory == "":
        return redirect("home")

    # Checks for space in the data in the searchbar (Product Name and Date entry)
    if " " in home_search_inventory:
        inventoryName = home_search_inventory.split(" ")[0]
        inventoryDate = home_search_inventory.split(" ")[1]

        # Stores the searched product IDs
        productID = []

        # Filters for the rows in Product Table with searched names in the searchbar
        home_searched_inventory_name = Product.objects.filter(productname__icontains=inventoryName)

        # Appends the searched product IDs into an array based on the product name
        for row in home_searched_inventory_name:
            productID.append(row.productid)

        # Stores the searched dates
        dateToday = []

        # Filters for the rows in Inventorycount Table with searched dates in the searchbar
        home_searched_inventory_date = Inventorycount.objects.filter(datetoday__icontains=inventoryDate)

        # Appends the searched inventory dates into an array
        for row in home_searched_inventory_date:
            dateToday.append(row.datetoday)

        # Filters for the rows in Inventorycount Table according to product ID(s) searched by product name and according to dates in the searchbar
        data = Inventorycount.objects.select_related('productid').filter(productid__in=productID, datetoday__in=dateToday).order_by('-datetoday')

    else:
        # Checks for '-' in the data in the searchbar (Date entry)
        if "-" in home_search_inventory:
            # Stores the searched dates
            dateToday = []

            # Filters for the rows in Inventorycount Table with searched dates in the searchbar
            home_searched_inventory_date = Inventorycount.objects.filter(datetoday__icontains=home_search_inventory)

            # Appends the searched inventory dates into an array
            for row in home_searched_inventory_date:
                dateToday.append(row.datetoday)

            # Filters for the rows in Inventorycount Table according to dates in the searchbar
            data = Inventorycount.objects.select_related('productid').filter(datetoday__in=dateToday).order_by('-datetoday')
        # Product Name Entry
        else:
            # Stores the searched product IDs
            productID = []

            # Filters for the rows in Product Table with searched names in the searchbar
            home_searched_inventory_name = Product.objects.filter(productname__icontains=home_search_inventory)

            # Appends the searched product IDs into an array based on the product name
            for row in home_searched_inventory_name:
                productID.append(row.productid)

            # Filters for the rows in Inventorycount Table according to product ID(s) searched by product name in the searchbar
            data = Inventorycount.objects.select_related('productid').filter(productid__in=productID).order_by('-datetoday')

    context = {
        'd':data,
        'title': home_search_inventory
    }

    return render(request, 'home_search.html', context)