from django.shortcuts import render, redirect
from django.http import HttpResponse
from inventory.models import Inventory, Product
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required
def home(request):
    data = Inventory.objects.select_related('productid').all().order_by('-currentdate')[:20]
    d = Inventory.objects.select_related('productid').all()

    basedcoat_count = d.filter(productid="1").count()
    brickjoint_count = d.filter(productid="9").count()
    plastering_count = d.filter(productid="6").count()
    screeding_count = d.filter(productid="7").count()
    skimcoat_count = d.filter(productid="2").count()
    thinbed_count = d.filter(productid="4").count()
    tileadhesive_count = d.filter(productid="8").count()
    tilefix_count = d.filter(productid="5").count()

    context = {
        'd':data,
        'basedcoat_count':basedcoat_count,
        'brickjoint_count':brickjoint_count,
        'plastering_count':plastering_count,
        'screeding_count':screeding_count,
        'skimcoat_count':skimcoat_count,
        'thinbed_count':thinbed_count,
        'tileadhesive_count':tileadhesive_count,
        'tilefix_count':tilefix_count,
    }

    return render(request, 'home.html', context)


@login_required
def search_home(request):
    # Runs when the search button is clicked
    if request.method == "POST":
        # Obtains the data in the searchbar
        home_search_inventory = request.POST['search_inventory']
    else:
        return redirect("home")

    # Checks for empty searchbar
    if home_search_inventory == "":
        return redirect("home")

    # Stores the searched product IDs
    productID = []

    # Filters for the rows in Product Table with searched names in the searchbar
    home_searched_inventory = Product.objects.filter(productname__icontains=home_search_inventory)

    # Appends the searched product IDs into an array based on the product name
    for row in home_searched_inventory:
        productID.append(row.productid)

    # Filters for the rows in Inventory Table according to product ID(s) searched by product name in the searchbar
    data = Inventory.objects.select_related('productid').filter(productid__in=productID).order_by('-currentdate')

    context = {
        'd':data,
        'title': home_search_inventory
    }

    return render(request, 'home_search.html', context)