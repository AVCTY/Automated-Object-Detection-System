from django.shortcuts import render, redirect
from django.http import HttpResponse
from inventory.models import Product, Inventorycount
from django.contrib.auth.decorators import login_required
from django.db.models import Sum

# Create your views here.
@login_required
def home(request):
    # get the first 20 records in the inventory and order it by descending date
    data = Inventorycount.objects.select_related('productid').all().order_by('-datetoday')[:20]
    # get all records in the inventory
    d = Inventorycount.objects.select_related('productid').all()

    # get the total number of bags produced according to each product id
    basedcoat_count = d.filter(productid="1").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    brickjoint_count = d.filter(productid="9").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    plastering_count = d.filter(productid="6").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    screeding_count = d.filter(productid="7").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    skimcoat_count = d.filter(productid="2").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    thinbed_count = d.filter(productid="4").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    tileadhesive_count = d.filter(productid="8").aggregate(TOTAL = Sum('noofbags'))['TOTAL']
    tilefix_count = d.filter(productid="5").aggregate(TOTAL = Sum('noofbags'))['TOTAL']

    # return context data
    context = {
        'd':data,
        'basedcoat_count':basedcoat_count,
        'brickjoint_count':brickjoint_count,
        'plastering_count':plastering_count,
        'screeding_count':screeding_count,
        'skimcoat_count':skimcoat_count,
        'thinbed_count':thinbed_count,
        'tileadhesive_count':tileadhesive_count,
        'tilefix_count':tilefix_count,
    }

    return render(request, 'home.html', context)

# Home Search Page
@login_required
def search_home(request):
    # Runs when the search button is clicked
    if request.method == "POST":
        # Obtains the data in the drop-down menu
        home_search_inventory = request.POST['search_bag']

        # Obtains the data in the calendar searchbar
        home_search_date = request.POST['search_date']
    else:
        return redirect("home")

    # Checks for non-selected drop-down menu and empty calendar searchbar
    if ((home_search_inventory == "") and (home_search_date == "")):
        return redirect("home")

    # Checks for selected bag in the drop-down menu
    if home_search_inventory != "":
        # Brings the user to the Inventory Page to show all products
        if home_search_inventory == "0":
            return redirect("view_inventory_count")
            
        # Assigns product bag names from the product ID to be shown on webpage
        if home_search_inventory == "1":
            bag_name = "Basedcoat"
        elif home_search_inventory == "2":
            bag_name = "Skim Coat"
        elif home_search_inventory == "4":
            bag_name = "Thin Bed"
        elif home_search_inventory == "5":
            bag_name = "Tile Fix"
        elif home_search_inventory == "6":
            bag_name = "Plastering"
        elif home_search_inventory == "7":
            bag_name = "Screeding"
        elif home_search_inventory == "8":
            bag_name = "Tile Adhesive"
        elif home_search_inventory == "9":
            bag_name = "Brick Joint"

        # Runs if there is no date selected in the calendar searchbar to filter and search by product bag name
        if home_search_date == "":
            # Displays the selected product bag name from the drop-down menu and "All Dates" on the webpage
            bag_view = bag_name
            date_view = "All Dates"

            # Filters for the rows in Inventorycount Table according to product ID(s) searched by product name from the drop-down menu
            data = Inventorycount.objects.select_related('productid').filter(productid__in=home_search_inventory).order_by('-datetoday')

    # Checks for selected date in the calendar searchbar
    if home_search_date != "":
        # Stores the searched dates
        dateToday = []

        # Filters for the rows in Inventorycount Table with the selected date in the calendar searchbar
        home_searched_inventory_date = Inventorycount.objects.filter(datetoday__icontains=home_search_date)

        # Appends the searched inventory dates into an array
        for row in home_searched_inventory_date:
            dateToday.append(row.datetoday)

        # Runs if there is no product bag name selected in the drop-down menu to filter and search by date
        if home_search_inventory == "":
            # Displays "All Bags" and the selected date from the calendar searchbar on the webpage
            bag_view = "All Bags"
            date_view = home_search_date

            # Filters for the rows in Inventorycount Table according to the date in the calendar searchbar
            data = Inventorycount.objects.select_related('productid').filter(datetoday__in=dateToday).order_by('-datetoday')

    # Checks for both the selected bag in the drop-down menu and selected date in the calendar searchbar
    if ((home_search_inventory != "") and (home_search_date != "")):
        # Displays the selected product bag name from the drop-down menu and the selected date from the calendar searchbar on the webpage
        bag_view = bag_name
        date_view = home_search_date

        # Filters for the rows in Inventorycount Table according to both the product ID(s) searched by product name from the drop-down menu and the date in the calendar searchbar
        data = Inventorycount.objects.select_related('productid').filter(productid__in=home_search_inventory, datetoday__in=dateToday).order_by('-datetoday')

    # return context data
    context = {
        'd':data,
        'title': bag_view,
        'date': date_view
    }

    return render(request, 'home_search.html', context)